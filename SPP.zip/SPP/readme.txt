DESCRIPTION
The 'algorithm' folder contains the main script that has to be launched in order to run either SPP or MMR. In the same folder, the computeObjectiveFunction script computes the objective function value for a given result.

The 'benchmark' folder contains the classes used to measure the time needed to run the algorithms.

The 'dataservice' folder contains the scripts that are used to create the dataset, according to some predefined rules. The drivers are the modules used to create different dataset types, e.g., synthetic or real.

The 'density' folder contains the module used to estimate the object density in the grid (see our extension on TODS for further details).

The 'retrievalmethod' folder contains the scripts that define the behavior of each retrieval method.

The 'score' folder contains those scripts that synthesize the score distribution of the pool of objects.

The 'voronoidiagram' folder contains the scripts used for creating the Voronoi diagram (either 2D or 3D).

EXAMPLE
We append to the set of algorithms a test (testSimpleSPPrun.m) which may be helpful to understand how to use the provided set of scripts.
