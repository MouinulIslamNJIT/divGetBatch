function Vdist = find_vertex_distances(centroids, V, C)

N_cells = size(centroids,1);
Vdist = NaN*ones(size(V,1), 1);

for i = 1:N_cells
   
    N_vert = size(C{i},2);
    dist = sqrt(sum((V(C{i},:) -  repmat(centroids(i,:), N_vert, 1)).^2, 2));
    Vdist(C{i}) = dist;
    if ~isnan(Vdist)
        break;
    end    
end