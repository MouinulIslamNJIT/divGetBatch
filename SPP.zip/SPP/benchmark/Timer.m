classdef Timer < handle
    %TIMER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties(GetAccess = protected, SetAccess = protected)
        startInstant;
        endInstant;
        totalObservationTime
    end
    
    methods
        function this = Timer()
            this.totalObservationTime = 0;
        end
        
        function start(this)
            this.endInstant = 0;
            
            this.startInstant = toc;
        end
        
        function stop(this)
            this.endInstant = toc;
            timeInterval = this.endInstant - this.startInstant;
            
            this.totalObservationTime = this.totalObservationTime + timeInterval;
        end
        
        function totalObservationTime = getTotalObservationTime(this)
            totalObservationTime = this.totalObservationTime;
        end
    end 
end
