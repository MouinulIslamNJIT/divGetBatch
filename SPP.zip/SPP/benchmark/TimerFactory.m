classdef (Sealed) TimerFactory < handle
    %tIMERFACTORY Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods(Static)
        function timer = newInstance()
            persistent numTimers;
            if isempty(numTimers)
                tic
            end
            timer = Timer();
            numTimers = numTimers + 1;
        end
    end
    
end