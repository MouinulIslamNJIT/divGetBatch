function [V, VtoV, FtoV] = prepare_convex_hull(anchors)

%V: list of all vertex coordinates 
V = anchors;

%FtoV: For each facet, list vertices
FtoVtemp = convhulln(V);
FtoV = cell(size(FtoVtemp,1),1);
for c = 1:size(FtoVtemp,1)
    FtoV{c} = FtoVtemp(c,:);
end

%VtoV: for each vertex, list all outgoing edges to neighboring vertexes
VtoV = find_vertex_edges_cu(V, FtoV);

