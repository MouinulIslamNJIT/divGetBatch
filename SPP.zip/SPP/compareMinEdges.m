function VtoV = compareMinEdges(VtoV)
    %% Variables
    numVertexes = size(VtoV, 1);  
    
    for i = 1:numVertexes
        toBeCanceled = 1;
        edges1 = VtoV{i};
        
        for j = 1:numVertexes
            edges2 = VtoV{j};
            
            if edges1(6,:) > edges2(7,:)
                toBeCanceled = 0;
                break;
            end
         
        end
        
        if toBeCanceled
            VtoV{i} = [];
        end
    end