function [bestObject, seenObjects] = pullingStrategy(dataService, voronoiDiagram, seenObjects, lambda, densityEstimator, pullingStrategyName, varargin)
    %% Variables
    VGRADS_THR = 1e-6;
    
    V = voronoiDiagram.vertices.coordinates;
    VtoV = voronoiDiagram.topology;
    centroidsFeatures = vertcat(voronoiDiagram.centroids.features);

    Vdist = voronoiDiagram.vertices.distancesFromCentroids;
    S_last = dataService.getLastScore();
    Vtau = (1-lambda)*S_last + lambda*Vdist;
    Vtau(isinf(V)) = NaN; 
    Vgrad = NaN*ones(size(V,1), 1);
        
    distance_to_vertex = zeros(size(V,1), 1);
    v = 0;
    top2 = [];
    
    if length(varargin) >= 1
        gradratio = varargin{1};
    else
        gradratio = 1;
    end
    
    % compute div score for seen objects
    seenObjects = computeDivScore(seenObjects, voronoiDiagram.centroids, lambda);
    
    %% SPP core
    while 1
        
        VgradS = NaN;
        
        switch pullingStrategyName
            case 'PA-SB'
                [~, v] = max(Vtau); 
                
                if dataService.getSDepth() > 1
                    VgradS = dataService.getScore(dataService.getSDepth()) - dataService.getScore(dataService.getSDepth()-1);
                    if abs(VgradS) < VGRADS_THR
                        VgradS = -VGRADS_THR;
                    end
                else
                    [top2, top2Score] = dataService.accessByScore();
                    VgradS = top2Score - dataService.getScore(1);
                end
                nextScore = ((1-lambda)*VgradS)/(lambda*Vgrad(v)) > gradratio;
                
            case 'PA'
                [~, v] = max(Vtau); 
                nextScore = ((1-lambda)*VgradS)/(lambda*Vgrad(v)) > gradratio;
            
            case 'RR'
                N_vert = size(V,1);
                if mod(dataService.getSumDepth(), N_vert+1) == 0
                    nextScore = 1;
                    v = 1;
                else
                    nextScore = 0;
                    if v == N_vert
                        v = 1;
                    else
                        v = v + 1;
                    end
                end
            otherwise
                error('ERROR: invalid pulling strategy')
        end
        
        if nextScore     
            if ~isempty(top2)
                next_obj = top2;
                S_last = top2Score;
                top2 = [];
            else
                [next_obj, S_last] = dataService.accessByScore();
            end
        else
            [next_obj, distance_to_vertex(v)] = dataService.accessByDistance(V(v,:));
        end
        

        % compute div score + add new object
        next_obj = computeDivScore(next_obj, voronoiDiagram.centroids, lambda);
        
        if length(seenObjects) == 1
            seenObjects = [seenObjects; next_obj];
        elseif ~ismember(vertcat(next_obj.features), vertcat(seenObjects.features), 'rows')
            seenObjects = [seenObjects; next_obj]; 
        end
        
        % update bound
        rho = densityEstimator.estimate(V);
        Vdepth = dataService.getVDepth(V(v, :));
        [Vtau(v), Vgrad(v)] = bounding_scheme(VtoV{v}, V(v,:), V, distance_to_vertex(v), centroidsFeatures, S_last, lambda, rho(v), Vdepth);
        
        % find best object
        [bestObjectDivScore, bestObjectId] = max(vertcat(seenObjects.divScore));
        bestObject = seenObjects(bestObjectId);
        
        % exit strategy
        if bestObjectDivScore >= max(Vtau)
            break;
        end   

    end        
end

