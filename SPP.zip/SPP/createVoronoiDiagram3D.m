function voronoiDiagram = createVoronoiDiagram3D(centroids, boundingRegion, ~)
    % adapt the input data structures
    lowerBound = boundingRegion.lowerBound;
    upperBound = boundingRegion.upperBound;
    centroidsFeatures = vertcat(centroids.features);
    anchors = [ upperBound lowerBound lowerBound; 
                lowerBound lowerBound lowerBound; 
                upperBound upperBound lowerBound; 
                lowerBound upperBound lowerBound;
                upperBound lowerBound upperBound;
                lowerBound lowerBound upperBound;
                upperBound upperBound upperBound;
                lowerBound upperBound upperBound ];
    
    % set default values
    epsScale = 1.5;
    isPlotRequired = 0;
    
    % call the legacy functions
    [V, VtoV, factor] = createBoundedVoronoiDiagram(centroidsFeatures, anchors, upperBound, lowerBound, isPlotRequired, epsScale);
    
    for i=1:size(V,1)
        edges = VtoV{i};
        numEdges = size(edges,2);

        % [endVertex; #cell; NaN; NaN; Rmax; dx; dy; dz]
        VtoV{i} = [NaN*ones(1,numEdges); cell2mat(edges(2,:)); NaN*ones(1,numEdges); NaN*ones(1,numEdges); cell2mat(edges(5,:)); cell2mat(edges(6,:)); cell2mat(edges(7,:)); cell2mat(edges(8,:))];
    end
  
    % adapt the output data structures
     voronoiDiagram = struct('centroids', centroids, ...
                             'topology', {VtoV}, ...
                             'vertices', struct('coordinates', V, ...
                                                'factor', factor));
end

