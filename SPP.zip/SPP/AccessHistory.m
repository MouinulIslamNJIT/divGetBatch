classdef AccessHistory < handle
    %ACCESSHISTORY Summary of this class goes here
    %   Detailed explanation goes here
    
    properties(GetAccess = protected, SetAccess = protected)
        accessesByDistanceHistory
        vBatched
        sDepth
        lastScore
        
        scores
        accessTimer
        
        TOLERANCE = 1.5*eps;
    end
    
    methods
        function this = AccessHistory()
            this.accessesByDistanceHistory = struct('coordinates', [], ...
                                                    'vDepth', []);
            this.sDepth = 0;
            this.vBatched = 0;
            this.lastScore = +Inf;
            
            this.scores = [];
            this.accessTimer = TimerFactory.newInstance();
        end
        
        function this = appendScores(this, scores)
            this.scores = [this.scores; scores];
            this.lastScore = scores(end);
        end
        
        function score = getScore(this, Ms)
            numSeenScores = length(this.scores);
            if Ms > numSeenScores
                throw(MException('AccessHistory:getScore', 'out of bound rank position specified'));
            end
            score = this.scores(Ms);
        end
                
        function lastScore = getLastScore(this)
            lastScore = this.lastScore;
        end
        
        function sDepth = getSDepth(this)
            sDepth = this.sDepth;
        end
        
        function vBatched = getVBatched(this)
            vBatched = this.vBatched;
        end
        
        function vDepth = getVDepth(this, vertex)
            if nargin == 1
                vertex = this.accessesByDistanceHistory.coordinates;
            end
       
            vertexId = this.getVertexIdFromCoordinates(vertex);
            if ~isempty(vertexId)
                vDepth = this.accessesByDistanceHistory.vDepth(vertexId);
            else
                vDepth = 0;
            end
        end
        
        function incrementVBatched(this, increment)
            this.vBatched = this.vBatched + increment;
        end
        
        function incrementVDepth(this, vertices, increments)
            verticesIds = this.getVertexIdFromCoordinates(vertices);
            if ~isempty(verticesIds)
                this.accessesByDistanceHistory.vDepth(verticesIds) =  this.accessesByDistanceHistory.vDepth(verticesIds) + increments;
            else
                this.accessesByDistanceHistory.coordinates = [this.accessesByDistanceHistory.coordinates; vertices];
                this.accessesByDistanceHistory.vDepth = [this.accessesByDistanceHistory.vDepth; increments];
            end
        end
        
        function incrementSDepth(this, Ms)
            this.sDepth = this.sDepth + Ms;
        end
        
        function accessTimer = getAccessTimer(this)
            accessTimer = this.accessTimer;
        end
        
        function sumDepth = getSumDepth(this)
            sumDepth = this.sDepth + this.vBatched + sum(this.accessesByDistanceHistory.vDepth);
        end
    end
    
    methods(Access = protected)
        function vertexId = getVertexIdFromCoordinates(this, vertex)
           
           if isempty(this.accessesByDistanceHistory.coordinates)
                vertexId = [];
                return;
           else
                vertexId = isfuzzymember(vertex, this.accessesByDistanceHistory.coordinates, this.TOLERANCE);
           end
           
           if sum(vertexId) == 0
               vertexId = [];
           end
        end
    end
    
end

