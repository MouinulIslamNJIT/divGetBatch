classdef (Sealed) VoronoiDiagramFactory < handle
    %VORONOIDIAGRAMFACTORY Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods(Static)
        function voronoiDiagram = newInstance(dataService)
            numDimensions = dataService.getObjectsDimensions();

            switch numDimensions
                case 2
                    voronoiDiagram = @createVoronoiDiagram2D;
                case 3
                    voronoiDiagram = @createVoronoiDiagram3D;
                otherwise
                    throw(MException('VoronoiDiagramFactory:newInstance', 'no voronoi diagram costruction method available for the given dimensions'));
            end
        end
    end
    
end

