function [adjCentroids, A, b, cellToPlanes] = findAdjCentroids(centroids, epsScale)
    %% Variables
    numCentroids = size(centroids,1);
    adjCentroids = cell(numCentroids,1);
    initialNumPlanes = 6; % six planes for the cube
    numPlanes = 0;
    
    %% Find the adjacency matrix
    if numCentroids <= 3
        
        for i = 1:numCentroids
            for j = 1: numCentroids
                
                    if i ~= j
                        adjCentroids{i} = [adjCentroids{i}, j];
                    end
            end
            
            numPlanes = numPlanes + size(adjCentroids{i},2);
        end
        
        
    elseif numCentroids > 3
     
        [Vv, CtoVv] = voronoin(centroids);
        numVertexes = size(Vv,1);
        
        for i=1:numCentroids
            CtoVv{i} = CtoVv{i}(CtoVv{i} ~= 1);
            
            for j=1:numCentroids
                
                if i == j
                    continue
                end
                
                CtoVv{j} = CtoVv{j}(CtoVv{j} ~= 1);
                if ~isempty(intersect(CtoVv{i}, CtoVv{j}))
                    adjCentroids{i} = unique([adjCentroids{i}, j]);
                end
                

            end
            
            numPlanes = numPlanes + size(adjCentroids{i}, 2);
        end
        
        

%% SECOND TRY
%         for i=1:numCentroids
%             for j=1:numCentroids
%                 
%                 if i == j
%                     continue
%                 end
%             
%                 for v=2:numVertexes
%                     if abs(norm(centroids(i,:) - Vv(v,:)) - norm(centroids(j,:) - Vv(v,:))) < 1.2*eps
%                         adjCentroids{i} = unique([adjCentroids{i}, j]);
%                     end
%                 end
%             
%             end
%             
%             numPlanes = numPlanes + size(adjCentroids{i}, 2);
%         end

%% FIRST TRY        
%         
%         for i = 1:numCentroids
%             sort(CtoVv{i});
%         end        
%         
%         for i= 1:numCentroids-1
%             isAdj = 0;
%            
%             for j = i+1:numCentroids
%                        
%                 % Remove one (inf. vertex) if present
%                 CtoVv{i} = CtoVv{i}(CtoVv{i} ~= 1);
%                 CtoVv{j} = CtoVv{j}(CtoVv{j} ~= 1);
% 
%                 % Add padding
%                 facetsI = zeros(1,numVertexes);
%                 facetsJ = facetsI;
% 
%                 facetsI(CtoVv{i}) = CtoVv{i};
%                 facetsJ(CtoVv{j}) = CtoVv{j};
% 
%                 % Check if the two facets are adj. (at least one common
%                 % vertex)
%                 isAdj = sum(facetsI == facetsJ);
%                 if isAdj ~= 0 
%                     adjCentroids{i} = unique([adjCentroids{i}, j]);
%                 end
%                     
%             end
%             
%             numPlanes = numPlanes + size(adjCentroids{i}, 2);
%         end    
%         
    end
    
    % each plane is counted twice because the matrix adjCentroids is
    % redundant (each relation is duplicated, e.g. if 1 with 3 there is
    % also 3 with 1)
    cellToPlanes = sparse(initialNumPlanes + numPlanes/2, numCentroids);
    A = NaN*ones(initialNumPlanes + numPlanes/2, 3);
    b = NaN*ones(initialNumPlanes + numPlanes/2, 1);
        

