function [A, b, cellToPlanes] = computePlanes(adjCentroids, centroids, A, initialA, initialb, cellToPlanes)
    %% Variables
    numCentroids = size(centroids, 1);
    idxCurrentPlane = 7;
    
    %% Add the constraints relative to the cube
    A(1:6,:) = initialA;
    b(1:6,:) = initialb;
    cellToPlanes(1:6,:) = 1; % a-priori every cell is made of all the planes of the cube
        
    %% Compute medium point and normal vector to plane
    for i = 1:numCentroids-1
            adjCentrTemp = adjCentroids{i};

            for j = 1: size(adjCentrTemp, 2)
                
                % tackle the symmetry of the adjCentroids matrix
                if adjCentrTemp(j) < i 
                    continue
                end

                M = (centroids(i,:) + centroids(adjCentrTemp(j),:))/2;
                n = centroids(i,:) - centroids(adjCentrTemp(j),:);

                A(idxCurrentPlane,:) = n;
                b(idxCurrentPlane) = n*M';

                % the plane belongs to the two adjacent cells
                cellToPlanes(idxCurrentPlane,i) = -1;
                cellToPlanes(idxCurrentPlane,adjCentrTemp(j)) = +1;

                idxCurrentPlane = idxCurrentPlane + 1;
            
            end
    end
    
    % Manage a bug we don't know how to solve
%     A = A(sum(abs(cellToPlanes),2) ~= 0,:);
%     cellToPlanes = cellToPlanes(sum(abs(cellToPlanes), 2) ~= 0,:);
    
    
