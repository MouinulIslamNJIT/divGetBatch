function [V, cellToVertexes] = pruneVertexes(V, ub, lb, epsScale)
    %% Variables
    numVertexes = size(V,1);
    numCentroids = max(V(:,4));
    idxNotDuplicatedVertexes = ones(numVertexes, 1);
    cellToVertexes = sparse(numVertexes, numCentroids);
    h = 1;
    
    %% For each vertex find its duplication and the cell it belongs to
    for i = 1:numVertexes
        
        if idxNotDuplicatedVertexes(i) ~= 0 && V(i,4) ~= 0 % if the vertex has been destroyed in a previous iteration OR it's a voronoin vertex we don't check it
            
%             % Find the components outside the convex hull
%             Vpos = V(i, V(i,1:3) >= 0);
%             Vneg = V(i, V(i,1:3) < 0);
%             numComponentsOutPos = length(find((Vpos - ub) > eps));
%             numComponentsOutNeg = length(find((abs(Vneg) - abs(lb)) > eps));
% 
%             % If the component is inside check if the vertex is not duplicated
%             if (numComponentsOutPos + numComponentsOutNeg) == 0

                idxCellsVertex = zeros(1,numCentroids);
                idxCellsVertex(V(i,4)) = 1;

                idxs = find(idxNotDuplicatedVertexes == 1);

                for k = 1:size(idxs,1);

                    j = idxs(k);

                    if j > i && V(j,4) ~= 0 % maintain the first copy of a duplicated vertex + wprkaround to keep voronoin vertexes
                        if abs(V(i,1:3) - V(j,1:3)) < 10*epsScale*eps

                            idxCellsVertex(V(j,4)) = 1;
                            idxNotDuplicatedVertexes(j) = 0;

                        end
                    end

                end

                cellToVertexes(h,:) = idxCellsVertex;
                h = h + 1;

%             end
        end
        
    end
    
    V = V(idxNotDuplicatedVertexes ~= 0, [1 2 3]);
    cellToVertexes = cellToVertexes(1:h-1,:);