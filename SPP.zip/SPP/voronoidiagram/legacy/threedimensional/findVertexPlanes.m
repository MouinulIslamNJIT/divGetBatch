function [normalVectors, idPlanes] = findVertexPlanes(vertex, A, b, idPlanes, epsScale)
    %% Variables
    normalVectors = NaN*ones(3,3);
  
    %% Find the planes of a given vertex
    normalVectors = A*vertex';
    idxVertex = find(abs(b - normalVectors) < epsScale*eps);

    normalVectors = A(idxVertex,:);
    idPlanes = idPlanes(idxVertex,:);
      