function [V, A, b, cellToPlanes, cellToVertexes, factor] = findIntersections(centroids, convHullVertexes, ub, lb, isPlotRequired, epsScale)
    %% Variables
    numCentroids = size(centroids,1);
    initialA = [1 0 0; -1 0 0; 0 1 0; 0 -1 0; 0 0 1; 0 0 -1];
    initialb = [ub; -lb; ub; -lb; ub; -lb];

    %% Compute the intersections
    if numCentroids == 1
        
        V = convHullVertexes;
        A = initialA;
        b = initialb;
        cellToPlanes = ones(6,1);
        cellToVertexes = ones(8,1);
        factor = 0.125*ones(8,1);
        return
    
    end

    [V, A, b, cellToPlanes, cellToVertexes, factor] = findIntersectionsNCentroids(centroids, initialA, initialb, ub, lb, isPlotRequired, epsScale);

    %% Draw the figure if required
   % if isPlotRequired
   %     figure;
   %     plotVoronoiConvexHull3D(V, centroids, ub, lb, A, b, cellToPlanes)
   % end