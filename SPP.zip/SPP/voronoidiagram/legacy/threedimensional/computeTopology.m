function VtoV = computeTopology(V, centroids, A, b, cellToPlanes, cellToVertexes, epsScale)
    %% Variables
    numVertexes = size(V,1);
    numCells = size(centroids,1); % centroids are the centroids adjacent to the centroid wrt which the edge is computed
    Rmax = cell(numVertexes,1);
    VtoV = cell(numVertexes,1);
  
    for i=1:numCells
        
        idxCellPlanes = cellToPlanes(:,i);
        idxCellVertexes = cellToVertexes(:,i);
        
        % Extract from A, b, V the planes, coefficient and vertexes of the
        % i-th cell
        cellPlanes = A(idxCellPlanes ~= 0,:);
        cellConstraints = b(idxCellPlanes ~= 0,:);
        cellVertexes = V(idxCellVertexes ~= 0,:);
        
        numCellVertexes = size(cellVertexes,1);
       
        % Label of the vertexes and planes of the i-th cell
        idVertexes = find(idxCellVertexes ~=0);
        idPlanes = find(idxCellPlanes ~= 0);
     
        
        for j=1:numCellVertexes
            
            [vertexPlanes, idVertexPlanes] = findVertexPlanes(cellVertexes(j,:), cellPlanes, cellConstraints, idPlanes, epsScale);
            vertexToCentroid = centroids(i,:) - cellVertexes(j,:);
            
            numVertexPlanes = size(vertexPlanes,1);
            
            for k=1:numVertexPlanes
                for h=k+1:numVertexPlanes
                    
                    % Compute the projection of the centroid on the edge
                    d = cross(vertexPlanes(k,:), vertexPlanes(h,:));
                    d = d / norm(d);
                    
                    % Check if the computed direction is correct and
                    % compute R
                    d = d*correctDirection(centroids(i,:), centroids(cellToVertexes(idVertexes(j),:) ~= 0,:), d, V(idVertexes(j),:), epsScale);
                    R = vertexToCentroid*d';
                    
                    % Store the cells the edge divides and create the edge
                    adjCells = findAdjCells(cellToPlanes, idVertexPlanes(k), idVertexPlanes(h), i);
                    VtoV{idVertexes(j)} = [VtoV{idVertexes(j)}, [NaN; i; adjCells; NaN; R; d(1); d(2); d(3)]];
                        
                end
            end
            
            
        end
    
    end
    
    VtoV = removeDuplicatedEdges(VtoV, epsScale);

    
