function adjCells = findAdjCells(cellToPlanes, idPlane1, idPlane2, cell1)
    adjCells = cell(1,1);

    % Handling the case in which both the planes are on the convex hull
    if idPlane1 <= 6 && idPlane2 <=6
        adjCells{1} = 0;
    else
        % Extract the cells on which the planes are
        cellToPlane1 = cellToPlanes(idPlane1, :);
        cellToPlane2 = cellToPlanes(idPlane2, :);
        
        adjCells{1} = abs(cellToPlane1) + abs(cellToPlane2);
        
        adjCells{1}(cell1) = 0; 


        if idPlane1 <= 6 || idPlane2 <= 6 
            adjCells{1}(adjCells{1} == 1) = 0;
        end
            
        
        adjCells{1} = find(adjCells{1} ~= 0);
        %adjCells{1} = adjCells{1}(adjCells{1} ~= cell1);
        
    end

    % fatal error
    if isempty(adjCells{1})
        error('unable to find adjacent cells');
        %adjCells{1} = -1;
    end   
    
