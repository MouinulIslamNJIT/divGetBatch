function VtoV = removeDuplicatedEdges(VtoV, epsScale)
    %% Variables
    numVertexes = size(VtoV, 1);
    
    for i=1:numVertexes
        edges = VtoV{i};
        numEdges = size(edges,2);
        cells = cell(numEdges,1);
        idxEdgesToKeep = ones(1,numEdges);
        
        for j=1:numEdges
            cells{j} = union(cell2mat(edges(2,j)), cell2mat(edges(3,j)));
            cells{j} = cells{j}(cells{j} ~= 0);
        end
        
        for h=1:numEdges
            if size(cells{h},2) > 1 % if the vertex is not a corner
                for k=h+1:numEdges
                    if size(cells{k},2) > 1 % if the vertex is not a corner
                        if size(cells{h},2) == size(cells{k},2)
                            if sum(sort(cells{h}) == sort(cells{k})) && abs(cell2mat(edges(5,h)) - cell2mat(edges(5,k))) < epsScale*eps
                                idxEdgesToKeep(k) = 0;
                            end
                        end
                    end
                end
            end
        end
        
        VtoV{i} = edges(:, find(idxEdgesToKeep ~= 0));
        
    end