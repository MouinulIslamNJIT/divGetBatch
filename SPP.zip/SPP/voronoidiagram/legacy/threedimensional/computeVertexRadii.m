function Rmax = computeVertexRadii(vertex, centroids, normalVectors, cellToPlanes, cellToVertexes)
    %% Variables
    numNormalVectors = size(normalVectors, 1);
    
    for i=1:numNormalVectors
        for j=i+1:numNormalVectors
       
            d = cross(normalVectors(i,:), normalVectors(j,:));
            d = d/norm(d);
            
        
        end
    end
