function isDirectionCorrect = correctDirection(centroid, centroids, d, vertex, epsScale)    
    %% Variables
    numCentroids = size(centroids,1);
    shiftedVertex = vertex + 100*epsScale*eps*d;
    
    %% Evaluate the direction if the centroids are less than 3
    if numCentroids < 3
        
        distance(1) = norm(centroid - shiftedVertex);
        distance(2) = norm(centroid - vertex);
        
        if distance(1) > distance(2)
            isDirectionCorrect = -1;
        else
            isDirectionCorrect = 1;
        end
        
    end
    
    %% Evaluate the direction if the centroids are greater or equal than 3
    if numCentroids >= 3
        
        distances = sqrt(sum((centroids - repmat(shiftedVertex, numCentroids, 1)).^2, 2));
        priorDistances = sqrt(sum((centroids - repmat(vertex, numCentroids, 1)).^2, 2));

        
        % Partition the distances matrix in two parts
        changedDistance = distances(abs(distances - distances(1)) > epsScale*eps);
        unchangedDistance = distances(abs(distances - distances(1)) < epsScale*eps);
        
        % degenerate case: an edge common to all cells, with all the
        % centroids on the same half-space
        if isempty(changedDistance)
            if priorDistances(1,:) < unchangedDistance(1,:)
                changedDistance = 1;
                unchangedDistance = 2;
            else
                changedDistance = 2;
                unchangedDistance = 1;
            end
         
        %at least one of the centroid is in a different half-space wrt all
        %the remaining centroids        
        else
           
            % Handle the particular case in which the changed direction is
            % direction(1)
            if size(changedDistance, 1) > 1
                unchangedDistance = changedDistance;
                changedDistance = distances(1);
            else
                unchangedDistance = unchangedDistance(1);
            end
        end
        
        % Evaluate the correct direction
        if changedDistance < unchangedDistance
            isDirectionCorrect = -1;
        else
            isDirectionCorrect = 1;
        end
        
    end
    