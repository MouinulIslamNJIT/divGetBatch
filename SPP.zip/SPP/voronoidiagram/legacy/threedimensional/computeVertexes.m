function [V, cellToPlanes, cellToVertexes, factor] = computeVertexes(A, b, centroids, cellToPlanes, ub, lb, isPlotRequired, epsScale)
    %% Variables
    numCentroids = size(cellToPlanes, 2);
    V = [];
    
    %% Find the vertexes of the Bounded Voronoi Diagram
    for i=1:numCentroids
        
        % Select the active planes
        ACell = A(abs(cellToPlanes(:,i)) == 1,:);
        bCell = b(abs(cellToPlanes(:,i)) == 1,:);
        
        % reverse the sign of the planes with coefficent -1 in cellToPlanes
        signPlanes = cellToPlanes(:,i);
        signPlanes = signPlanes(signPlanes ~= 0);
        
        ACell = ACell.*repmat(signPlanes,1,3);
        bCell = bCell.*signPlanes;
     
        % con2vert doesn't support sparse matrix so we need to full them
        ACell = full(ACell);
        bCell = full(bCell);
             
        % Find the vertexes of the cell
        VCell = vertexEnumeration(ACell, bCell);
        VCell = [VCell, i*ones(size(VCell,1),1)]; % [(x,y,z), #cell]
        
        %Remove the vertexes outside the convex hull
        VCell = VCell(abs(VCell(:,1)) - 0.5 < epsScale*eps,:);
        VCell = VCell(abs(VCell(:,2)) - 0.5 < epsScale*eps,:);
        VCell = VCell(abs(VCell(:,3)) - 0.5 < epsScale*eps,:);
        
        V = [V; VCell];
    
        % remove cube facets which don't belong to the cell
        cellToPlanes(:,i) = removeCubeFacets(VCell, cellToPlanes(:,i), epsScale); 
        
        % Plot the single cell if required
        if isPlotRequired
            subplot(2,round(numCentroids / 2), i)
            plotVoronoiConvexHull3D(VCell, centroids(i,:), ub, lb, A, b, cellToPlanes(:,i));
        end
    
    end
    
    %% Remove vertexes duplicated vertex + creates cellToVertexes
    [V, cellToVertexes] = pruneVertexes(V, ub, lb, epsScale);
    
    %% Compute the percentage of sphere inside the Voronoi diagram for each
    %% vertex
    numVertexes = size(V,1);
    factor = ones(numVertexes, 1);
    factor(sum(abs(abs(V) - 0.5) < epsScale*eps,2) == 1) = 0.5;
    factor(sum(abs(abs(V) - 0.5) < epsScale*eps,2) == 2) = 0.25;
    factor(sum(abs(abs(V) - 0.5) < epsScale*eps,2) == 3) = 0.125;
