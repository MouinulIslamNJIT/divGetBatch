function OneCellToPlanes = removeCubeFacets(VCell, OneCellToPlanes, epsScale)
    %% Variables
    limits(1) = max(VCell(:,1));
    limits(2) = min(VCell(:,1));
    
    limits(3) = max(VCell(:,2));
    limits(4) = min(VCell(:,2));
  
    limits(5) = max(VCell(:,3));
    limits(6) = min(VCell(:,3));
    
    b = [0.5,-0.5,0.5,-0.5,0.5,-0.5];
    
    %% Check if the cube facets are included in the cell
    OneCellToPlanes(1:6) = abs(limits - b) < epsScale*eps;

    
