function [V, VtoV, factor] = createBoundedVoronoiDiagram(centroids, anchors, ub, lb, isPlotRequired, epsScale)

    [V, A, b, cellToPlanes, cellToVertexes, factor] = findIntersections(centroids, anchors, ub, lb, isPlotRequired, epsScale);
    VtoV = computeTopology(V, centroids, A, b, cellToPlanes, cellToVertexes, epsScale);