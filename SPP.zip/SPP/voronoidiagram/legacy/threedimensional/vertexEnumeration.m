function V = vertexEnumeration(A, b)
    %% Variables
    numPlanes = size(A, 1);
    numVertexes = factorial(numPlanes)/(6*factorial(numPlanes - 3));
    
    V = (-1)*ones(numVertexes, 3);
    h = 1;
    
    %% Find vertexes
    for i=1:numPlanes - 2
        for j=i+1:numPlanes - 1
            for k=j+1:numPlanes
                
                vertexPlanes = A([i j k], :);
                vertexCoefficients = b([i j k], :);
                
                if det(vertexPlanes) == 0
                    continue
                end
  
                V(h, :) = vertexPlanes\vertexCoefficients;
                
                h = h + 1;
            
            end
        end
    end
    
    numVertexes = h-1;
    V = V(1:numVertexes,:);
    newV = NaN*ones(numVertexes,3);
    
    %% Check if the vertexes are inside the polyhedron
    h = 1;
    for i=1:numVertexes
        
        if A*V(i,:)' - b < eps
        	newV(h,:) = V(i,:);
            h = h + 1;
        end
    end
    
    numVertexes = h-1;
    V = V(1:numVertexes,:);
    V = newV;
    
    