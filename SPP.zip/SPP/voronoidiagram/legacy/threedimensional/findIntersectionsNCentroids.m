function [V, A, b, cellToPlanes, cellToVertexes, factor] = findIntersectionsNCentroids(centroids, initialA, initialb, ub, lb, isPlotRequired, epsScale)    
    
    [adjCentroids, A, b, cellToPlanes] = findAdjCentroids(centroids, epsScale);
    [A, b, cellToPlanes] = computePlanes(adjCentroids, centroids, A, initialA, initialb, cellToPlanes);
    [V, cellToPlanes, cellToVertexes, factor] = computeVertexes(A, b, centroids, cellToPlanes, ub, lb, isPlotRequired, epsScale);
    
    

    
    

   
          

       
   
   
   
