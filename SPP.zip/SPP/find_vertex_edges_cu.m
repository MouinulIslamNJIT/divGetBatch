function VtoV = find_vertex_edges_cu(V, CtoV)

N_facets = size(CtoV,1);
N_vert = size(V,1);
VtoVtemp = cell(N_vert, 1);
VtoV = cell(N_vert, 1);

for v = 1:N_vert
   VtoVtemp{v} = cell(2,1); 
end


for i = 1:N_facets
    Nv = length(CtoV{1});
    for j = 1:Nv;
        v1 = CtoV{i}(j);
        if j < Nv
            v2 = CtoV{i}(j+1);
        else
            v2 = CtoV{i}(1);
        end
        
        VtoVtemp{v1}{1} = [VtoVtemp{v1}{1}, v2];
        VtoVtemp{v2}{1} = [VtoVtemp{v2}{1}, v1];
        VtoVtemp{v1}{2} = [VtoVtemp{v1}{2}, i];
        VtoVtemp{v2}{2} = [VtoVtemp{v2}{2}, i];

    end    
    
    
end

% add cells divided by each edge
for v = 1:N_vert
    edges = unique(VtoVtemp{v}{1});
    E = length(edges);
    for e = 1:E
       indexes = find(VtoVtemp{v}{1} == edges(e));
       cells = unique(VtoVtemp{v}{2}(indexes));
       VtoV{v} = [VtoV{v}, [edges(e); cells(1); NaN]];
    end
end

% add edge direction (outgoing direction from reference vertex)
for v = 1:N_vert 
    edges = VtoV{v};
    E = size(edges,2);
    
    VtoVnew = NaN*ones(5, E); %1: vertex, 2: facet, 3: NaN, 4: dir, 5: dist
    
    for e = 1:E
        V1 = V(v,:); 
        V2 = V(edges(1,e), :);
        dV = (V2 - V1)./norm(V2 - V1);
        [theta, rho] = cart2pol(dV(1), dV(2));
        dist = NaN;
        VtoVnew(:,e) = [edges(1:3,e); theta; dist];        
    end
    VtoV{v} = VtoVnew;
end


