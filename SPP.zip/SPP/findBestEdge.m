function idEdgeMin = findBestEdge(edges, b, c)
    %% Variables
    numEdges = size(edges,2);
    distanceMaxMin = -Inf;
    idEdgeMin = -1;
    
    %% Compute the min       
    et = 1;
    for j=1:numEdges
        if edges(5,j) > 0

            distanceMinEdge = computeDistance(edges(5,j), b(et), c(et));
            if distanceMaxMin < distanceMinEdge
                distanceMaxMin = distanceMinEdge;
                idEdgeMin = et;
            end

            et = et + 1;

        end
    end