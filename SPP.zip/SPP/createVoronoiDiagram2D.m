function voronoiDiagram = createVoronoiDiagram2D(centroids, boundingRegion, k)
    
    % adapt the input data structures
    centroidsFeatures = vertcat(centroids.features);

    % call the legacy functions
    persistent Vh;
    persistent VtoVh;
    persistent FtoVh;
    
    if isempty(Vh)       
        upperBound = boundingRegion.upperBound;
        lowerBound = boundingRegion.lowerBound;
        anchors = [lowerBound lowerBound; lowerBound, upperBound; upperBound, lowerBound; upperBound, upperBound];
        
        [Vh, VtoVh, FtoVh] = prepare_convex_hull(anchors);
    end
    
    if k <= 3 
        [V, VtoV, Vdist, N_vertv] = merge_convexhull_voronoi(Vh, VtoVh, FtoVh, centroidsFeatures, NaN, NaN, NaN);
    else
        [Vv, VtoVv, Vdistv] = prepare_voronoi_diagram(centroidsFeatures);
        [V, VtoV, Vdist, N_vertv] = merge_convexhull_voronoi(Vh, VtoVh, FtoVh, centroidsFeatures, Vv, VtoVv, Vdistv);
    end
    
    N_vert = size(V, 1);
    N_verth = size(Vh, 1);
    factor = ones(N_vert, 1);
    factor(1:N_verth) = 0.25;
    factor(N_verth + N_vertv + 1: N_vert) = 0.5;
    
    % adapt the output data structures
    voronoiDiagram = struct('centroids', centroids, ...
                            'topology', {VtoV}, ...
                            'vertices', struct('distancesFromCentroids', Vdist, ...
                                               'coordinates', V, ...
                                               'factor', factor));

end