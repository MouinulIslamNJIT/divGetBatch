function omega = find_offsets(Vi, V1, V2)

N_vert = size(Vi,1);
omega = NaN*ones(N_vert, 1);

for v = 1:N_vert
   
    if abs(V2(1) - V1(1)) > eps
       omega(v) = (Vi(v,1) - V1(1)) / (V2(1) - V1(1));
    else
       omega(v) = (Vi(v,2) - V1(2)) / (V2(2) - V1(2));
    end
    
end