function objects = computeDivScore(objects, centroids, lambda)
    numSeenObjects = size(objects,1);
    numCentroids = size(centroids, 1);
    
    seenObjectsFeatures = vertcat(objects.features);
    centroidsFeatures = vertcat(centroids.features);
    
    divScores = cell(numSeenObjects, 1);
    
    for i = 1:numSeenObjects
        distancesToCentroids = sqrt(sum((repmat(seenObjectsFeatures(i,:), numCentroids, 1)-centroidsFeatures).^2,2));
        divScores{i} = (1 - lambda)*objects(i).score + lambda*min(distancesToCentroids);
    end
    
    [objects.divScore] = divScores{:};
    
end
