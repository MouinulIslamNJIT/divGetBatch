function F = computeObjectiveFunction(resultSet, lambda)
    K = length(resultSet);
    distances = NaN*ones(K,1);
    
    for k = 1:K
        currentObject = resultSet(k);
        otherObjects = resultSet(setdiff(1:K,k));
        
        [~,distances(k)] = kNearestNeighbors(vertcat(otherObjects.features),currentObject.features,1);
    end
    
    F = (1-lambda)*mean(vertcat(resultSet.score)) + lambda*min(distances);
end

