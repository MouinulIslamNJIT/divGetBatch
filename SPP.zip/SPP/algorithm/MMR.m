function [resultSet, CPUTimer] = MMR(dataService, K, lambda)
    resultSet = struct('features', cell(K,1), ...
                       'score', cell(K,1),...
                       'divScore', cell(K,1));
    
    CPUTimer = TimerFactory.newInstance();
                   
    % Retrieve dataset
    dataSet = [];
    while 1
       newObject = dataService.accessByScore();
       if isempty(newObject)
           break;
       end
       dataSet = [dataSet; newObject];
    end
    N = size(dataSet, 1);
    
    % Top-1 by score
    CPUTimer.start();
    resultSet(1) = dataSet(1);
    
    for k=2:K
        resultSetFeatures = vertcat(resultSet.features);
        dataSetFeatures = vertcat(dataSet.features);
        
        [~,resultSetIdxs] = ismember(resultSetFeatures, dataSetFeatures, 'rows');
        otherObjects = dataSet(setdiff(1:N, resultSetIdxs));
        otherObjectsFeatures = vertcat(otherObjects.features);
        
        [~, maxDist] = kNearestNeighbors(resultSetFeatures, otherObjectsFeatures, 1);
        score = (1-lambda)*vertcat(otherObjects.score) + lambda*maxDist;
        
        [~,idx] = max(score);
        resultSet(k) = otherObjects(idx);
    end
    CPUTimer.stop();
end

