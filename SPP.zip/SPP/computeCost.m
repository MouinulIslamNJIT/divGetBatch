function cost = computeCost(r, rho, factor, dimensions)

    factor = factor';
    rho = rho';
    
    switch(dimensions)
        case 2
           cost = pi*sum(rho.*factor.*r.^2);
        case 3
           cost = 4/3*pi*sum(rho.*factor.*r.^3);
    end
    