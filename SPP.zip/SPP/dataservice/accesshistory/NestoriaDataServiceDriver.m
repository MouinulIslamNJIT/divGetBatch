classdef NestoriaDataServiceDriver < handle
    %NESTORIADATASERVICEDRIVER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (GetAccess = protected, SetAccess = protected)
        objectsByScore
        scoresByScore
        objectDimensions
        
        numFeatureVectors
        URL
        retrievedPagesByScore
        coordNorthEast
        coordSouthWest
        priceMin
    end
    
    methods
        function this = NestoriaDataServiceDriver(requestParameters)
            if nargin == 1
                NestoriaURL = 'http://api.nestoria.co.uk/api?action=search_listings&encoding=xml';
                this.URL = strcat(NestoriaURL, '&listing_type=', requestParameters.listingType, ...
                                               '&property_type=all&price_max=', num2str(requestParameters.priceMax), ...
                                               '&price_min=', num2str(requestParameters.priceMin), ...
                                               '&room_min=0&sort=', requestParameters.sortingMode);
                                           
                this.coordNorthEast = requestParameters.coordNorthEast;
                this.coordSouthWest = requestParameters.coordSouthWest;
                
                % total number of feature vectors
                response = retrieveResponse(this, 1, strcat('&south_west=', this.coordSouthWest, ...
                                                            '&north_east=', this.coordNorthEast));
                try
                    this.numFeatureVectors = str2double(response.getAttributes.getNamedItem('total_results').getValue);
                catch 
                    this.numFeatureVectors = 0;
                end
                                           
                this.reset();
            end
        end

        function numFeatureVectors = getNumFeatureVectors(this)
            numFeatureVectors = this.numFeatureVectors;
        end
        
        function featureVectorsDimensions = getFeatureVectorsDimensions(this)
            featureVectorsDimensions = 2;
        end
        
        function [objects,scores] = accessByScore(this,sDepth, Ms)
            
            if sDepth >= this.numFeatureVectors()
                objects = [];
                scores = [];
                return;
            end

            additionalParameters = strcat('&south_west=', this.coordSouthWest, ...
                                          '&north_east=', this.coordNorthEast);
            while (sDepth + Ms) >= size(this.objectsByScore, 1)
                this.retrievedPagesByScore = this.retrievedPagesByScore + 1;
                [newObjects, newScores] = retrievePage(this,this.retrievedPagesByScore,additionalParameters);
                
                if isempty(newObjects)
                    this.numFeatureVectors = length(this.objectsByScore) + length(newScores);
                    break;
                end
                
                this.objectsByScore = [this.objectsByScore; newObjects];
                this.scoresByScore = [this.scoresByScore; newScores];
            end
            
            if sDepth + Ms <= this.numFeatureVectors()
                objects = this.objectsByScore(sDepth+1:sDepth+Ms,:);
                scores = this.scoresByScore(sDepth+1:sDepth+Ms);
            else
                objects = this.objectsByScore(sDepth+1:end, :);
                scores = this.scoresByScore(sDepth+1:end, :);
            end
            
            % score normalization
            if sDepth+Ms == 1
                this.priceMin = scores;
            end
            scores = this.priceMin ./ scores;
        end
        
        function [objects, scores] = batchedAccess(this, vertices, radii)
            objects = [];
            scores = [];
            numVertices = size(vertices, 1);
            
             for i = 1:numVertices
                 currentPage = 0;
                 additionalParameters = strcat('&centre_point=',num2str(vertices(i,1)), ',',num2str(vertices(i,2)),',',num2str(radii(i)),'km');
                 while 1
                     currentPage = currentPage + 1;
                     [newObjects, newScores] = retrievePage(this, currentPage, additionalParameters);
                     if isempty(newObjects)
                         break;
                     else
                        objects = [objects; newObjects]; 
                        scores = [scores; newScores];
                     end
                 end
             end
        end
        
        function [objects,scores] = accessByDistance(this, vertex, numNearestNeighbors)
            objects = [];
            scores = [];
            currentPage = 0;
            additionalParameters = strcat('&centre_point=',num2str(vertex(1)),',', num2str(vertex(2)));
            radius = 2;
            
            while size(objects,1) < numNearestNeighbors
               currentPage = currentPage + 1;
               [newObjects, newScores] = retrievePage(this, currentPage, strcat(additionalParameters,',',num2str(radius),'km'));
               objects = [objects; newObjects];
               scores = [scores; newScores];
               radius = radius + 2;
            end
            
            objects = objects(1:numNearestNeighbors,:);
            scores = scores(1:numNearestNeighbors);
        end
        
        function reset(this)
            this.objectsByScore = [];
            this.scoresByScore = [];
            this.retrievedPagesByScore = 0;
        end
    end
    
    methods(Access = protected)
        function [objects, scores] = retrievePage(this, page, additionalParameters)
            objects = [];
            scores = [];
            response = retrieveResponse(this, page, additionalParameters);
            
            numListings = response.getChildNodes.getLength;
            child = response.getFirstChild;
            
            for i = 1:numListings
               if strcmp(child.getNodeName, 'listings')
                   try
                        latitude = str2double(child.getAttributes.getNamedItem('latitude').getValue);
                        longitude = str2double(child.getAttributes.getNamedItem('longitude').getValue);
                        price = str2double(child.getAttributes.getNamedItem('price').getValue);
                        objects = [objects; latitude longitude];
                        scores = [scores;price];
                   catch 
                      continue; 
                   end
               end
               child = child.getNextSibling;
            end
        end
        
        function response = retrieveResponse(this, page, additionalParameters)
            if nargin == 2
               additionalParameters = ''; 
            end
            tempfile = 'file.xml';
            
            newPageURL = strcat(this.URL, '&page=', num2str(page), additionalParameters);
            urlwrite(newPageURL,tempfile);
            
            f = fopen(tempfile ,'r','l','ISO-8859-1');
            strResponse = fread(f,'*char')';
            fclose(f);
            delete(tempfile) 
            
            try
                documentBuilder = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                xmlResponse = documentBuilder.newDocumentBuilder.parse(java.io.StringBufferInputStream(strResponse));
            catch err
                error(getReport(err))
            end
            response = xmlResponse.getChildNodes.item(0).getChildNodes.item(3);
        end
    end
end

