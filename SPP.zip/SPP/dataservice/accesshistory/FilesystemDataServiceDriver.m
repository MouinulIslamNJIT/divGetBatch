classdef FilesystemDataServiceDriver < handle
    %FILESYSTEMDATASERVICEDRIVER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties(GetAccess = protected, SetAccess = protected)
        syntheticDataServiceDriver
    end
    
    methods
        function this = FilesystemDataServiceDriver(csvPath, featureVectorsIds, scoreId, rankingPolicy, boundingRegion)
            if nargin >= 4
                csvData = importdata(csvPath);
                featureVectors = csvData(:, featureVectorsIds);
                scores = csvData(:, scoreId);
                
                scores(isnan(scores)) = 0;
                scores = (scores - min(scores)) / (max(scores) - min(scores));
                
                discardIds = isnan(featureVectors(:,1));
                featureVectors = featureVectors(~discardIds, :);
                scores = scores(~discardIds);
                
                if nargin == 5
                    featureVectors = this.normalizeData(featureVectors, boundingRegion);
                end
                
                this.syntheticDataServiceDriver = SyntheticDataServiceDriver(featureVectors, scores, rankingPolicy);
            end
        end
        
        function numFeatureVectors = getNumFeatureVectors(this)
            numFeatureVectors = this.syntheticDataServiceDriver.getNumFeatureVectors;
        end
        
        function featureVectorsDimensions = getFeatureVectorsDimensions(this)
            featureVectorsDimensions = this.syntheticDataServiceDriver.getFeatureVectorsDimensions();
        end
        
        function [featureVectors, scores] = accessByScore(this, sDepth, Ms)
            [featureVectors, scores] = this.syntheticDataServiceDriver.accessByScore(sDepth, Ms);
        end
        
        function [featureVector, score, distancesToVertex] = accessByDistance(this, vertex, vDepth, numNearestNeighbors)
            [featureVector, score, distancesToVertex] = this.syntheticDataServiceDriver.accessByDistance(vertex, vDepth, numNearestNeighbors);
        end
        
        function [featureVectors, scores, numObjects] = batchedAccess(this, vertices, radii)
            [featureVectors, scores, numObjects] = this.syntheticDataServiceDriver.batchedAccess(vertices, radii);
        end
        
        function reset(this)
        end
    end
    
    methods(Access = protected)
        function featureVectors = normalizeData(this, featureVectors, boundingRegion)
            numDimensions = size(featureVectors,2);
            
            for dim = 1:numDimensions
                lb = min(featureVectors(:,dim));
                ub = max(featureVectors(:,dim));
                featureVectors(:,dim) = (featureVectors(:,dim) - lb) / (ub - lb);
            end
            
            featureVectors = featureVectors + boundingRegion.lowerBound;
        end    
    end
end

