classdef SyntheticDataServiceDriver < handle
    %SYNTETHICDATASERVICEDRIVER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties(GetAccess = protected, SetAccess = protected)
        featureVectors
        scores
        
        numFeatureVectors
        featureVectorsDimensions;
        tree
    end
    
    methods
        function this = SyntheticDataServiceDriver(featureVectors, scores, rankingPolicy)
            if nargin <= 2
                rankingPolicy = 'descend';
            end
            
            if nargin >= 2
                [featureVectors, scores] = this.orderByQueryRelevance(featureVectors, scores, rankingPolicy);
                
                this.featureVectorsDimensions = size(featureVectors, 2);
                this.featureVectors = featureVectors; 
                this.scores = scores;
                       
                this.numFeatureVectors = size(featureVectors, 1);
                this.tree = kdtree_build(this.featureVectors);
            end
        end
        
        function numFeatureVectors = getNumFeatureVectors(this)
            numFeatureVectors = this.numFeatureVectors;
        end
        
        function featureVectorsDimensions = getFeatureVectorsDimensions(this)
            featureVectorsDimensions = this.featureVectorsDimensions;
        end
             
        function [featureVectors, scores] = accessByScore(this, sDepth, Ms)
            if sDepth >= this.numFeatureVectors
                featureVectors = [];
                scores = [];
                return;
            end
            
            if sDepth + Ms <= this.numFeatureVectors
                featureVectors = this.featureVectors(sDepth+1:sDepth+Ms, :);
                scores = this.scores(sDepth+1:sDepth+Ms);
            else
                featureVectors = this.featureVectors(sDepth+1:end, :);
                scores = this.scores(sDepth+1:end);
            end
        end
        
        function [featureVector, score, distancesToVertex] = accessByDistance(this, vertex, vDepth, numNearestNeighbors)
            
            neighborsIds = kdtree_k_nearest_neighbors(this.tree, vertex, vDepth + numNearestNeighbors);
            neighborsIds = flipud(neighborsIds);
            
            featureVector = this.featureVectors(neighborsIds(end), :);
            score = this.scores(neighborsIds(end));
            
            distancesToVertex = sqrt(sum((featureVector - vertex).^2));
        end
        
        function [featureVectors, scores, numObjects] = batchedAccess(this, vertices, radii)
            numVertices = size(vertices, 1);
            numObjects = NaN*ones(numVertices, 1);
            featureVectorsIds = [];
            
            for vertexId=1:numVertices
                distancesToVertex = sqrt(sum((this.featureVectors - repmat(vertices(vertexId,:), size(this.featureVectors, 1), 1)).^2, 2));
                neighborsIds = find(distancesToVertex < radii(vertexId))';
                numObjects(vertexId) = length(neighborsIds);
                
                featureVectorsIds = [featureVectorsIds, neighborsIds];
            end
            
            featureVectorsIds = unique(featureVectorsIds);
            featureVectors = this.featureVectors(featureVectorsIds, :);
            scores = this.scores(featureVectorsIds, :);
        end
        
        function reset(this)
        end
    end
    
    methods(Access = protected)       
        function [featureVectors, scores] = orderByQueryRelevance(this, featureVectors, scores, rankingPolicy)
            [scores, scoresIds] = sort(scores, rankingPolicy);
            featureVectors = featureVectors(scoresIds, :);
                
            if strcmp(rankingPolicy, 'ascend')
                scores = 1 - scores;
            end
        end
    end
end

