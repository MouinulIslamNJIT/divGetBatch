classdef DataService < handle
    %DATASERVICE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties(GetAccess = protected, SetAccess = protected)
        accessHistory
        scoreEstimator
        dataServiceDriver
    end
    
    methods
        function this = DataService(dataServiceDriver)
            if nargin == 1
                this.accessHistory = AccessHistory();              
                this.dataServiceDriver = dataServiceDriver;
            end
        end
        
        function accessHistory = getAccessHistory(this)
            accessHistory = this.accessHistory;
        end
        
        function objectsDimensions = getObjectsDimensions(this)
            objectsDimensions = this.dataServiceDriver.getFeatureVectorsDimensions();
        end
        
        function numObjects = getNumObjects(this)
            numObjects = this.dataServiceDriver.getNumFeatureVectors();
        end
        
        function score = getScore(this, Ms)
            score = this.accessHistory.getScore(Ms);
        end
                
        function sDepth = getSDepth(this)
            sDepth = this.accessHistory.getSDepth();
        end
        
        function vDepth = getVDepth(this, vertex)
            if nargin == 1
                vDepth = this.accessHistory.getVDepth();
            else
                vDepth = this.accessHistory.getVDepth(vertex);
            end
        end
        
        function sumDepth = getSumDepth(this)
            sumDepth = this.accessHistory.getSumDepth();
        end
        
        function lastScore = getLastScore(this)
            lastScore = this.accessHistory.getLastScore();
        end
        
        function [objects, lastScore] = accessByScore(this, Ms)
            if nargin == 1
                Ms = 1;
            end
            
            if Ms == 0
                objects = [];
                return;
            end
            
            % get timer
            accessTimer = this.accessHistory.getAccessTimer();
            
            % get objects by score
            accessTimer.start();
            [featureVectors, scores] = this.dataServiceDriver.accessByScore(this.accessHistory.getSDepth(), Ms);
            accessTimer.stop();
            
            objects = this.constructObjects(featureVectors, scores);
            
            if isempty(objects)
                return;
            end
            
            % update history 
            lastScore = scores(end);
            this.accessHistory.incrementSDepth(Ms);
            this.accessHistory.appendScores(scores);
        end
        
        function [object, distancesToVertex] = accessByDistance(this, vertex, numNearestNeighbors)  
            if nargin == 2
                numNearestNeighbors = 1;
            end
            
            % get history + timer
            accessTimer = this.accessHistory.getAccessTimer();
            vDepth = this.accessHistory.getVDepth(vertex);
            
            % get objects by distance
            accessTimer.start();
            [featureVector, score, distancesToVertex] = this.dataServiceDriver.accessByDistance(vertex, vDepth, numNearestNeighbors);
            accessTimer.stop();
            
            object = this.constructObjects(featureVector, score);

            % update history
            this.accessHistory.incrementVDepth(vertex, 1);
        end
        
        function [objects, numObjects] = batchedAccess(this, vertices, radii) 
            % get timer
            accessTimer = this.accessHistory.getAccessTimer();
            
            % get objects by batched access
            accessTimer.start();
            [featureVectors, scores, numObjects] = this.dataServiceDriver.batchedAccess(vertices, radii);   
            accessTimer.stop();
            
            objects = this.constructObjects(featureVectors, scores);
            
            % update history
            this.accessHistory.incrementVBatched(sum(numObjects));
        end
        
        function resetAccessHistory(this)
            this.accessHistory = AccessHistory();
            this.dataServiceDriver.reset();
        end
    end
    
    methods(Access = protected)
        function objects = constructObjects(this, featureVectors, scores)
            
            if isempty(featureVectors)
                objects = [];
                return;
            end
            
            objects = struct('features',    num2cell(featureVectors, 2), ...
                             'score',       num2cell(scores), ...
                             'divScore',    []);
        end
    end
end

