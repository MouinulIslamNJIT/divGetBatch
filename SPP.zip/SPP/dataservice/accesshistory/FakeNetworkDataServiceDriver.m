classdef FakeNetworkDataServiceDriver
    %FAKENETWORKDATASERVICEDRIVER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (GetAccess = protected, SetAccess = protected)
        accessTime
        filesystemDataServiceDriver
    end
    
    methods
        function this = FakeNetworkDataServiceDriver(accessTime, filesystemDataServiceDriver)
            if nargin == 2
                pause on

                this.accessTime = accessTime;
                this.filesystemDataServiceDriver = filesystemDataServiceDriver;
            end
        end
        
        function numFeatureVectors = getNumFeatureVectors(this)
            numFeatureVectors = this.filesystemDataServiceDriver.getNumFeatureVectors();
        end
   
        function [objects,scores] = accessByScore(this,sDepth, Ms)
           [objects, scores] = this.filesystemDataServiceDriver.accessByScore(sDepth, Ms);
           pause(this.accessTime);
        end
        
        function [objects, scores, numObjects] = batchedAccess(this, vertices, radii)
           [objects, scores, numObjects] = this.filesystemDataServiceDriver.batchedAccess(vertices, radii);
           pause(this.accessTime);
        end
       
        function [objects, scores, distancesToVertex] = accessByDistance(this, vertex, vDepth, numNearestNeighbors)
           [objects, scores, distancesToVertex] = this.filesystemDataServiceDriver.accessByDistance(vertex, vDepth, numNearestNeighbors);
           pause(this.accessTime);
        end
        
        function featureVectorsDimensions = getFeatureVectorsDimensions(this)
            featureVectorsDimensions = this.filesystemDataServiceDriver.getFeatureVectorsDimensions();
        end
        
        function reset(this)
        end
    end
    
end

