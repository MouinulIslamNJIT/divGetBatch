function VtoV = find_vertex_edges(V, C, CtoV)

N_cells = size(CtoV,1);
N_vert = size(V,1);
VtoVtemp = cell(N_vert, 1);
VtoV = cell(N_vert, 1);


if size(C, 1) == 3
    edges = NaN*ones(3, 3);
    for e = 1:3
        if e <= 2
            c1 = e;
            c2 = e+1;
        else
            c1 = e;
            c2 = 1;
        end

        edges(:,e) = [1; c1; c2];        
    end
    VtoV{2} = edges;    
else

    for v = 1:N_vert
       VtoVtemp{v} = cell(2,1); 
    end

    for i = 1:N_cells
        Nv = size(CtoV{i},2);
        for j = 1:Nv;
            v1 = CtoV{i}(j);
            if j < Nv
                v2 = CtoV{i}(j+1);
            else
                v2 = CtoV{i}(1);
            end

            VtoVtemp{v1}{1} = [VtoVtemp{v1}{1}, v2];
            VtoVtemp{v2}{1} = [VtoVtemp{v2}{1}, v1];
            VtoVtemp{v1}{2} = [VtoVtemp{v1}{2}, i];
            VtoVtemp{v2}{2} = [VtoVtemp{v2}{2}, i];

        end  
    end

    % add cells divided by each edge
    for v = 1:N_vert
        edges = unique(VtoVtemp{v}{1});
        E = length(edges);
        for e = 1:E
           indexes = find(VtoVtemp{v}{1} == edges(e));
           cells = VtoVtemp{v}{2}(indexes);
           if length(cells) == 2
               VtoV{v} = [VtoV{v}, [edges(e); cells(1); cells(2)]];
           elseif length(cells) == 4 %special handling for cells with two infinite edges
               cells = sort(cells);
               if cells(1) == cells(2)
                   VtoV{v} = [VtoV{v}, [edges(e); cells(1); cells(3)], [edges(e); cells(1); cells(4)]];
               elseif cells(2) == cells(3)
                   VtoV{v} = [VtoV{v}, [edges(e); cells(2); cells(1)], [edges(e); cells(2); cells(4)]];               
               elseif cells(3) == cells(4)
                   VtoV{v} = [VtoV{v}, [edges(e); cells(3); cells(1)], [edges(e); cells(3); cells(2)]];               
               else
                   error('something wrong');
               end
           end
        end
    end
end

% add edge direction (outgoing direction from reference vertex)
for v = 2:N_vert %skip edges starting from vertex 1 (vertex at infinity)
    edges = VtoV{v};
    E = size(edges,2);

    VtoVnew = NaN*ones(5, E); %1: vertex, 2: cell1, 3: cell2, 4: dir, 5: dist

    % push edge pointing to vertex at infinity at the end of the list,
    % since it needs to be treated after all the others
    [temp, indexes] = sort(edges(1,:),'descend');
    edges = edges(:,indexes);

    for e = 1:E
        if edges(1,e) ~= 1
            V1 = V(v,:); 
            V2 = V(edges(1,e), :);
            dV = (V2 - V1)./norm(V2 - V1);
            [theta, rho] = cart2pol(dV(1), dV(2));
            C1 = C(edges(2,e),:);
            C2 = C(edges(3,e),:);
            M = (C1+C2)/2;
            dist = (M(1) - V1(1)) / cos(theta);
            dist = min(dist, norm(V2-V1));
%             dist2 = norm(M - V1);

            VtoVnew(:,e) = [edges(1:3,e); theta; dist];        
        else
            V1 = V(v,:); 
            c1 = edges(2,e);
            c2 = edges(3,e);
            C1 = C(c1,:);
            C2 = C(c2,:);
            M = (C1+C2)/2;
            m = (M(2) - V1(2))/(M(1) - V1(1));
            theta = atan(m);

            % create two points along the line passing through V1 at either
            % sides of V1. The correct direction is the half line that
            % contains the point whose nearest neighbor is either C1 or C2
            X1 = V1 + [cos(theta), sin(theta)];
            X2 = V1 + [cos(theta + pi), sin(theta + pi)];

            CX = C(unique(edges(2:3,:)),:);

            distX1 = sum((repmat(X1, size(CX,1), 1) - CX).^2,2);
            distX2 = sum((repmat(X2, size(CX,1), 1) - CX).^2,2);

            [temp, index1] = min(distX1);
            [temp, index2] = min(distX2);

            if norm(CX(index1,:) - C1) == 0 || norm(CX(index1,:) - C2) == 0
%                 theta = theta;
            elseif norm(CX(index2,:) - C1) == 0 || norm(CX(index2,:) - C2) == 0
                theta = theta + pi;
            end
            dist = (M(1) - V1(1)) / cos(theta);
            VtoVnew(:,e) = [edges(1:3,e); theta; dist];        
        end
    end
    VtoV{v} = VtoVnew;
end
end

