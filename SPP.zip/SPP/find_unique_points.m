function Vout = find_unique_points(Vin)

N_vert = size(Vin, 1);

Vout = Vin(1,:);
vo = 1;
for v = 2:N_vert
   
    dist = sum((repmat(Vin(v,:), size(Vout,1), 1) - Vout).^2,2);
    if min(dist) > eps
        vo = vo + 1;
        Vout(vo,:) = Vin(v,:);
    end
end
    

