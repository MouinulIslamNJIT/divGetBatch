classdef (Sealed) DensitySamplerFactory < handle
    %DENSITYSAMPLERFACTORY Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods(Static)
        function densitySampler = newInstance(dataService)
            numDimensions = dataService.getObjectsDimensions();
            
            switch numDimensions
                case 2
                    densitySampler = DensitySampler2D(dataService);
                case 3
                    densitySampler = DensitySampler3D(dataService);
                otherwise
                    throw(MException('DensitySamplerFactory:newInstance', 'no density sampler available for the given dimensions'));
            end
        
        end
    end
    
end

