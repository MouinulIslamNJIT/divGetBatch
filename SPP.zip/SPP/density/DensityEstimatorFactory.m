classdef (Sealed) DensityEstimatorFactory < handle
    %DENSITYESTIMATORFACTORY Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods(Static)
        function densityEstimator = newInstance(estimatorType, dataService, varargin)
            switch estimatorType
                case 'interp-grid'
                    densityEstimator = newInterpGridInstance(dataService);
                
                case 'uniform'
                    if length(varargin) < 1
                        throw(MException('DensityEstimatorFactore:newInstance', 'no bounding region specified'));
                    end
                    boundingRegion = varargin{1};
                    densityEstimator = newUniformInstance(dataService, boundingRegion);
               
                otherwise
                    throw(MException('DensityEstimatorFactory:newInstance', 'unknown density estimator'));
            end
        end
    end   
end

function densityEstimator = newInterpGridInstance(dataService)
    numDimensions = dataService.getObjectsDimensions();

    switch numDimensions
        case 2
            densityEstimator = DensityInterpGridEstimator2D();
        case 3
            densityEstimator = DensityInterpGridEstimator3D();
        otherwise
            throw(MException('DensityEstimatorFactory:newInstance', 'no density estimator available for the given dimensions'));
    end
end

function densityEstimator = newUniformInstance(dataService, boundingRegion)
    numDimensions = dataService.getObjectsDimensions();
    numObjects = dataService.getNumObjects();

    switch numDimensions
        case 2
            area = (boundingRegion.upperBound - boundingRegion.lowerBound)^2;
        case 3
            area = (boundingRegion.upperBound - boundingRegion.lowerBound)^3;
        otherwise
            throw(MException('DensityEstimatorFactory:newInstance', 'no density estimator available for the given dimensions'));
    end

    uniformDensity = numObjects / area;
    densityEstimator = DensityUniformEstimator(uniformDensity);
end 
