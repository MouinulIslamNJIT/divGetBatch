classdef DensitySampler2D < DensitySampler
    %BOUNDINGREGIONSAMPLER2D Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods
        function this = DensitySampler2D(dataService)
            if isempty(dataService)
                dataService = 0;
            end
            this@DensitySampler(dataService);
        end
        
        function area = computeArea(this, radius)
            area = radius^2*pi;
        end
        
        function numProbingLocations = computeNumProbingLocations(this, numQuadrants)
            numProbingLocations = (numQuadrants+1)^2;
        end
        
        function radius = computeInitialDensityRadius(this, numProbingLocations, areaPercentage)
            radius = sqrt(areaPercentage./(numProbingLocations*pi));
        end
        
        function samples = sample(this, boundingRegion, radius, numQuadrants)
            lowerBound = boundingRegion.lowerBound;
            upperBound = boundingRegion.upperBound;
            step = (upperBound - lowerBound)/numQuadrants;
                        
            [X, Y] = meshgrid([lowerBound:step:upperBound], [lowerBound:step:upperBound]');
            
            probingLocations = [X(:), Y(:)];
            numProbingLocations = size(probingLocations, 1);
            probingLocationsIds = 1:numProbingLocations;
            
            estimatedDensity = NaN*ones(numProbingLocations, 1);

            while ~isempty(probingLocationsIds)
                [~, numObjects] = this.dataService.batchedAccess(probingLocations(probingLocationsIds, :), radius*ones(length(probingLocationsIds), 1));
                area = this.computeArea(radius);
                estimatedDensity(probingLocationsIds) = numObjects / area;

                probingLocationsIds = probingLocationsIds(estimatedDensity(probingLocationsIds) == 0);
                radius = radius *this.INCREASE_RATE;
            end

            samples = [X(:), Y(:), estimatedDensity]; 
        end
    end
    
end

