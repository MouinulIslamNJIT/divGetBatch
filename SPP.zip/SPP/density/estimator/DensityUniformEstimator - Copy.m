classdef DensityUniformEstimator < DensityEstimator
    %DENSITYUNIFORMESTIMATOR Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        uniformDensity
    end
    
    methods
        function this = DensityUniformEstimator(uniformDensity)
            if nargin == 1
                this.uniformDensity = uniformDensity;
            end
        end
        
        function train(this, ~, ~)
            throw(MException('DensityUniformEstimator:train', 'operation not supported'));
        end
        
        function estimatedDensity = estimate(this, point)
            numPoints = size(point, 1);
            estimatedDensity = this.uniformDensity*ones(numPoints, 1);
        end
    end
    
end

