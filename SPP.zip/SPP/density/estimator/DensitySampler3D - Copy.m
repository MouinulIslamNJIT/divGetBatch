classdef DensitySampler3D < DensitySampler
    %DENSITYSAMPLER3D Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods
        function this = DensitySampler3D(dataService)
            if isempty(dataService)
                dataService = 0;
            end
            this@DensitySampler(dataService);
        end
        
        function area = computeArea(this, radius)
            area = (4/3)*pi*radius^3;
        end
        
        function numProbingLocations = computeNumProbingLocations(this, numQuadrants)
            numProbingLocations = (numQuadrants+1)^3;
        end
        
        function radius = computeInitialDensityRadius(this, numProbingLocations, areaPercentage)
            radius = (areaPercentage.*3./(4.*pi.*numProbingLocations)).^(1/3);
        end

        function samples = sample(this, boundingRegion, radius, numQuadrants)
            lowerBound = boundingRegion.lowerBound;
            upperBound = boundingRegion.upperBound;
            step = (upperBound - lowerBound)/numQuadrants;
            
            [X, Y, Z] = meshgrid(lowerBound:step:upperBound, lowerBound:step:upperBound, lowerBound:step:upperBound);
            probingLocations = [X(:), Y(:), Z(:)];
            numProbingLocations = size(probingLocations, 1);
            probingLocationsIds = 1:numProbingLocations;
            
            estimatedDensity = NaN*ones(numProbingLocations, 1);
            
            while ~isempty(probingLocationsIds)
                [~, numObjects] = this.dataService.batchedAccess(probingLocations(probingLocationsIds, :), radius*ones(length(probingLocationsIds),1));
                area = this.computeArea(radius);
                estimatedDensity(probingLocationsIds) = numObjects / area;
                
                probingLocationsIds = probingLocationsIds(estimatedDensity(probingLocationsIds) == 0);
                radius = radius *this.INCREASE_RATE;
            end

            samples = [X(:), Y(:), Z(:), estimatedDensity];
        end
    end
    
end

