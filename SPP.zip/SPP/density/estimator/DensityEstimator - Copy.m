classdef DensityEstimator < handle
    %DENSITYESTIMATOR Summary of this class goes here
    %   Detailed explanation goes here
    
    properties(GetAccess = protected, SetAccess = protected)
        parameters;
    end
    
    methods(Abstract)
        train(this, densitySamples, numProbingLocations);
        estimatedDensity = estimate(this, point); 
    end 
end

