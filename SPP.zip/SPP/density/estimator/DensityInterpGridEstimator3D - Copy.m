classdef DensityInterpGridEstimator3D < DensityEstimator
    %DENSITYESTIMATOR3D Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods
        function train(this, densitySamples, numProbingLocations)
            if nargin == 3
                this.parameters = cell(4,1);
                this.parameters{1} = reshape(densitySamples(:,1), int32(numProbingLocations^(1/3)), int32(numProbingLocations^(1/3)), int32(numProbingLocations^(1/3)));
                this.parameters{2} = reshape(densitySamples(:,2), int32(numProbingLocations^(1/3)), int32(numProbingLocations^(1/3)), int32(numProbingLocations^(1/3)));
                this.parameters{3} = reshape(densitySamples(:,3), int32(numProbingLocations^(1/3)), int32(numProbingLocations^(1/3)), int32(numProbingLocations^(1/3)));
                this.parameters{4} = reshape(densitySamples(:,4), int32(numProbingLocations^(1/3)), int32(numProbingLocations^(1/3)), int32(numProbingLocations^(1/3)));
            end
        end
        
        function estimatedDensity = estimate(this, point)
            estimatedDensity = interp3(this.parameters{1}, this.parameters{2}, this.parameters{3}, this.parameters{4}, ...
                                       point(:,1), point(:,2), point(:,3));
        end
    end
    
end

