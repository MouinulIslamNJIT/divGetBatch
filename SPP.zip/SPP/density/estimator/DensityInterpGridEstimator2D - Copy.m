classdef DensityInterpGridEstimator2D < DensityEstimator
    %DENSITYESTIMATOR2D Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods      
        function train(this, densitySamples, numProbingLocations)
            if nargin == 3
                this.parameters = cell(3,1);
                this.parameters{1} = reshape(densitySamples(:,1), sqrt(numProbingLocations), sqrt(numProbingLocations));
                this.parameters{2} = reshape(densitySamples(:,2), sqrt(numProbingLocations), sqrt(numProbingLocations));
                this.parameters{3} = reshape(densitySamples(:,3), sqrt(numProbingLocations), sqrt(numProbingLocations));
            end
        end
        
        function estimatedDensity = estimate(this, point)
            estimatedDensity = interp2(this.parameters{1}, this.parameters{2}, this.parameters{3}, point(:,1), point(:,2));
        end
    end
    
end

