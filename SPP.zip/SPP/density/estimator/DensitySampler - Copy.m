classdef DensitySampler < handle
    %BOUNDINGREGIONSAMPLER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties(GetAccess = protected, SetAccess = protected)
        dataService
        INCREASE_RATE = 1.01;
    end
    
    methods
        function this = DensitySampler(dataService)
            if nargin == 1
                this.dataService = dataService;
            end
        end
        
        function [densitySamples, numProbingLocations] = sampleByDistance(this, boundingRegion, areaPercentage, numQuadrants)
            
            numProbingLocations = this.computeNumProbingLocations(numQuadrants);
            radius = this.computeInitialDensityRadius(numProbingLocations, areaPercentage);
            densitySamples = this.sample(boundingRegion, radius, numQuadrants); 
        end
        
        function setIncreaseRate(this, increaseRate)
            this.INCREASE_RATE = increaseRate;
        end
    end
    
    
    methods(Abstract)
        numProbingLocations = computeNumProbingLocations(this, numQuadrants);
        radius = computeInitialDensityRadius(this, numDummyProbingLocations, areaPercentage);
        densitySamples = sample(this, boundingRegion, radius);
        area = computeArea(this, radius);
    end
end

