function [Vtau, Vgrad] = bounding_scheme(edges, V1, V, distance_to_vertex, centroids, S_last, lambda, rho, Vdepth)

Vtau = -Inf;
Vgrad = NaN;
E = size(edges, 2);

for e = 1:E
    edge_length = norm(V(edges(1, e),:) - V1);
    if isnan(edges(5,e)) && distance_to_vertex <= edge_length % convex hull
        theta = edges(4, e);
        dir = [cos(theta), sin(theta)];
        V2 = V1 + distance_to_vertex*dir;
        if size(centroids,1) == 1
            C1 = centroids;
        else
            warning(0, 'to be completed'); 
        end
        upper_bound = (1-lambda)*S_last + lambda*norm(V2 - C1);
        if upper_bound > Vtau
            Vtau = upper_bound;
            x1 = sum((C1 - V1).*dir);
            x2 = sqrt(norm(C1 - V1)^2 - x1^2);
            t = distance_to_vertex;
            Vgrad1 = -(x1 - t)./sqrt(x2^2 + (x1 - t)^2);
            Vgrad2 = 1/sqrt(rho*pi*Vdepth);
            Vgrad = Vgrad1 * Vgrad2;
        end

      
    else % voronoi
        if distance_to_vertex < edges(5, e) && distance_to_vertex <= edge_length % Edge might contribute to Vtau
            theta = edges(4, e);
            dir = [cos(theta), sin(theta)];
            V2 = V1 + distance_to_vertex*dir;
            c1 = edges(2,e);
            C1 = centroids(c1,:);
            upper_bound = (1-lambda)*S_last + lambda*norm(V2 - C1);
            if upper_bound > Vtau
                Vtau = upper_bound;
                x1 = sum((C1 - V1).*dir);
                x2 = sqrt(norm(C1 - V1)^2 - x1^2);
                t = distance_to_vertex;
                Vgrad1 = -(x1 - t)./sqrt(x2^2 + (x1 - t)^2);
                Vgrad2 = 1/sqrt(rho*pi*Vdepth);
                Vgrad = Vgrad1 * Vgrad2;
            end
        end
    end

end

