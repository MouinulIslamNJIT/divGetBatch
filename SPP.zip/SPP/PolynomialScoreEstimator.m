classdef PolynomialScoreEstimator < ScoreEstimator
    %POLYNOMIALSCOREESTIMATOR Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods
        function train(this, scoreSamples)
            throw(MException('PolynomailScoreEstimator:train', 'operation not supported'));
        end
        
        function scores = computeScore(this, rankPosition)
            scores = this.parameters{1}*rankPosition^this.parameters{2} + this.parameters{3};
        end
        
        function setParameters(this, parameters)
            this.parameters = parameters;
        end
    end
    
end

