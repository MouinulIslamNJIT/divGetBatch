classdef (Sealed) ScoreDecayDistribution < handle
    %SCOREDECAYFACTORY Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods(Static)
        function scores = sample(scoreDecayType, numObjects, varargin)
            switch scoreDecayType
                case 'uniform'
                    scoreMax = varargin{1};
                    scores  = scoreMax - 1.0*rand(numObjects, 1);
                case 'exponential'
                    scoreMax = varargin{1};
                    scores = exprnd(1, numObjects, 1);
                    scores = scoreMax*scores./max(scores);
                otherwise
                    throw(MException('ScoreDecayFactory:newInstance', 'unknown score decay'));
            end
        end
    end
    
end

