classdef ScoreEstimator < handle
    %SCOREESTIMATOR Summary of this class goes here
    %   Detailed explanation goes here
    
    properties(GetAccess = protected, SetAccess = protected)
        parameters
    end
    
    methods
    end
    
    methods(Abstract)
        train(this, scoreSamples);
        computeScore(this, rankPosition);
        setParameters(this, parameters);
    end
    
end

