classdef LinearScoreEstimator < ScoreEstimator
    %LINEARSCOREESTIMATOR Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods
        function this = LinearScoreEstimator()
        end
        
        function train(this, scoreSamples)
            rankPosition = scoreSamples(:, 1:end-1);
            scores = scoreSamples(:, end);
            
            linearRegressor = polyfitn(rankPosition, scores, 1);
            this.parameters = linearRegressor.Coefficients';
        end
        
        function scores = computeScore(this, rankPosition)
            numObjects = size(rankPosition, 1);
            
            rankPosition = [rankPosition, ones(numObjects, 1)]; 
            scores = rankPosition*this.parameters;
        end
        
        function setParameters(this, parameters)
            if size(parameters, 2) > 1
                parameters = parameters';
            end
            this.parameters = parameters;
        end
    end
    
end

