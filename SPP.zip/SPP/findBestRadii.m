function [tau, r] = findBestRadii(distanceBestEdges, M, rho, factor, epsilon, dimensions)

    % ordering the matrix from the worst to the best vertex
    [~, idSorted]= sort(distanceBestEdges(:,3), 'descend');
    distanceBestEdges = distanceBestEdges(idSorted,:);

    if M == 0
        numVertexes = size(distanceBestEdges, 1);
        r = zeros(1, numVertexes);
        tau = distanceBestEdges(1,3); % maximum possible value of tau (if i don't explore anything the value remains fixed on the maximum)
        return;
    end

   
    % compute tau(r_u) coefficients
    b = distanceBestEdges(end, 2);
    c = distanceBestEdges(end, 3);
    distanceUB = distanceBestEdges(1,3);
    distanceLB = computeDistance(b/(-2), b, c);
    
    [tau, r] = binarySearch(distanceBestEdges, M, rho, factor, dimensions, distanceUB, distanceLB, epsilon, 0, 0);
 