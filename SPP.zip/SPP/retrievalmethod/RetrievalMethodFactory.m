classdef (Sealed) RetrievalMethodFactory < handle
    %RETRIEVALMETHODFACTORY Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods(Static)
        function retrievalMethod = newInstance(retrievalMethodName, varargin)
            switch retrievalMethodName
                case 'BA-SB'
                    M = varargin{1};
                    scoreEstimator = varargin{2};
                    retrievalMethod = @(dataService, voronoiDiagram, seenObjects, lambda, densityEstimator) BatchedAccess(dataService, voronoiDiagram, seenObjects, lambda, densityEstimator, scoreEstimator, M);
               
                case 'BA'
                    M = varargin{1};
                    retrievalMethod = @(dataService, voronoiDiagram, seenObjects, lambda, densityEstimator) BatchedAccess(dataService, voronoiDiagram, seenObjects, lambda, densityEstimator, [], M);
                
                case 'PA-SB'
                    pullingStrategyName = retrievalMethodName;
                    gradratio = varargin{1};
                    retrievalMethod = @(dataService, voronoiDiagram, seenObjects, lambda, densityEstimator) pullingStrategy(dataService, voronoiDiagram, seenObjects, lambda, densityEstimator, pullingStrategyName, gradratio);
                    
                case {'PA', 'RR'}
                    pullingStrategyName = retrievalMethodName;
                    retrievalMethod = @(dataService, voronoiDiagram, seenObjects, lambda, densityEstimator) pullingStrategy(dataService, voronoiDiagram, seenObjects, lambda, densityEstimator, pullingStrategyName);
                
                otherwise
                    throw(MException('RetrievalMethodFactory:newInstance', 'unknown retrieval method'));
            end
        end
    end
    
end

