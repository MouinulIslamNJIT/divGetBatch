function r = computeSolution(distanceBestEdges, tau)
    %% Variables
    numVertexes = size(distanceBestEdges, 1);
    r = NaN*ones(1,numVertexes);
    
    for i=1:numVertexes
        %% Variables
        idVertex = distanceBestEdges(i,1);
        b = distanceBestEdges(i,2);
        c = distanceBestEdges(i,3);
        
        Rmax = b/(-2);
        distanceMax = c;
        distanceMin = computeDistance(Rmax, b, c);
        
        %% Find Intersections
        if tau > distanceMax
            r(idVertex) = 0;
        elseif tau < distanceMin
            r(idVertex) = Rmax;
        else
            r(idVertex) = (-b - sqrt(b^2 - 4*c + 4*tau))/2;
        end
    
    end