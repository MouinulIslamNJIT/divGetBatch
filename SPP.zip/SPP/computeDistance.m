function distanceValues = computeDistance(radiusValues, b, c)

    distanceValues = radiusValues.^2 + b.*radiusValues + c;
    
end

