function resultSet = testSimpleSPPrun()
    K = 5;
    gradratio = 1;
    N = 8;
    lambda = 0.75;
    
    seed = 1;
    rng(seed);
    
    S_MAX = 1;
    
    % bounding region 
    boundingRegion = struct('upperBound', 0.5, ...
                            'lowerBound', -0.5);                        
            
    % generate data set
    featureVectors = [-0.4 -0.4; -0.2 0.4; 0.45 0.2; 0.3 -0.3;-0.2 -0.3; -0.5 0.7; 0.85 0.2; 0.1 -0.3];
    scores = [1 0.9 0.8 0.7 0.5 0.4 0.1 0.4]; 
    scatter(featureVectors(:,1), featureVectors(:,2))
    ylim([-0.5 0.5])
    xlim([-0.5 0.5])

    % create data service
    dataService = DataService(SyntheticDataServiceDriver(featureVectors, scores, 'descend'));

    % density
    densityEstimator = DensityEstimatorFactory.newInstance('uniform', dataService, boundingRegion);

    % retrieval method
    retrievalMethod = RetrievalMethodFactory.newInstance('PA-SB', gradratio);

    % SPP
    [resultSet, ~] = SPP(dataService, lambda, K, boundingRegion, retrievalMethod, densityEstimator);
    for i=1:K
        disp(resultSet(i))
    end
    accessHistory = dataService.getTotalNumAccess()
    message = sprintf("number of pruning = %d ",N*K - accessHistory)
    disp(message)
    
end

