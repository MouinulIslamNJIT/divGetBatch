classdef (Sealed) FeatureVectorsDistribution < handle
    %FEATUREVECTORSFACTORY Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
    end
    
    methods(Static)
        function featureVectors = sample(spatialDistributionType, boundingRegion, numObjects, numDimensions, varargin)
            switch spatialDistributionType
                case 'uniform'
                    featureVectors = boundingRegion.lowerBound + (boundingRegion.upperBound - boundingRegion.lowerBound)*rand(numObjects, numDimensions);
                
                case 'clusters'
                    mean = varargin{1};
                    stdDev = varargin{2};
                    
                    if length(mean) ~= length(stdDev) && length(mean) ~= length(numObjects)
                        throw(MException('FeatureVectorsDistribution:sample', 'mean, variance and numObjects vectors must have same size'));
                    end
                    
                    featureVectors = zeros(sum(numObjects), numDimensions);
    
                    idx = 1;
                    for cluster=1:length(mean)
                        featureVectors(idx:idx - 1 + numObjects(cluster), :) = generateCluster(mean{cluster}, stdDev{cluster}, numObjects(cluster), numDimensions, boundingRegion);
                        idx = sum(numObjects(1:cluster)) + 1;
                    end
            end
        end
    end 
end


function clusterFeatureVectors = generateCluster(mean, stdDev, numObjects, numDimensions, boundingRegion)
        numClusterValidObjects = 0;
        clusterFeatureVectors = [];
        
        while numClusterValidObjects < numObjects
            clusterFeatureVectors = [clusterFeatureVectors; mvnrnd(mean, stdDev, numObjects - numClusterValidObjects)]; 
            
            validObjectsIdx = zeros(numObjects, numDimensions);
            for dim=1:numDimensions
                features = clusterFeatureVectors(:, dim);
                validObjectsIdx(:, dim) = features > boundingRegion.lowerBound & features < boundingRegion.upperBound;
            end
            clusterFeatureVectors = clusterFeatureVectors(logical(prod(validObjectsIdx, 2)), :);
            numClusterValidObjects = size(clusterFeatureVectors, 1);
        end
end
