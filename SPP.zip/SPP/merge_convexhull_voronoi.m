function [V, VtoV, Vdist, N_vertv] = merge_convexhull_voronoi(Vh, VtoVh, FtoVh, centroids, Vv, VtoVv, Vdistv)

if isnan(Vv)
    N_vertv = 0;
else
    N_vertv = size(Vv, 1);
end
N_verth = size(Vh, 1);
N_centr = size(centroids, 1);


if N_centr == 1
   V = Vh;
   VtoV = VtoVh;
   Vdist =  sqrt(sum((Vh -  repmat(centroids, N_verth, 1)).^2, 2));

   for v = 1:size(VtoV,1)
       edges = VtoV{v};
       E = size(edges,2);
       for e = 1:E
            edges(2,e) = 1;
            c = 1;
            theta = edges(4,e);
            % project centroid on the edge
            distmax = (centroids(c,:) - V(v,:))*[cos(theta);sin(theta)];
            edges(5,e) = distmax;           
       end
       VtoV{v} = edges;
   end

elseif N_centr > 1
    %find bounding box
    ub = max(Vh, 1);
    lb = min(Vh, 1);
    range = max(ub - lb);
    maxrange = 10*max(range);

    N_facetsh = size(FtoVh, 1);

    segmentsh = NaN*ones(N_facetsh, 4);

    for fh = 1:N_facetsh
        vh = FtoVh{fh};
        facets = Vh(vh,:);
        segmentsh(fh,:) = [facets(1,:), facets(2,:)];
    end
    
    if N_centr == 2    
        V = Vh;
        VtoV = VtoVh;
        N_vert = N_verth;

        C1 = centroids(1,:);
        C2 = centroids(2,:);
        M = (C1+C2)/2;
        m = (C2(2) - C1(2))/(C2(1) - C1(1));
        theta(1) = atan(-(1/m));
        theta(2) = theta(1) + pi;
        P = [M + maxrange*[cos(theta(1)), sin(theta(1))];
             M + maxrange*[cos(theta(2)), sin(theta(2))]];
        for i = 1:2
            segmentv = [M, P(i,:)];
            out = lineSegmentIntersect(segmentv,segmentsh);
            facet = out.intAdjacencyMatrix;
            Vt = [out.intMatrixX(facet), out.intMatrixY(facet)];
            
            % add new vertex
            V = [V; Vt];
            edges = NaN*ones(5, 3);
            
            % update edge
            v1 = FtoVh{facet}(1);
            v2 = FtoVh{facet}(2);
    
            % split existing edge
            % v1 -> v2
            edges1 = VtoV{v1}(1,:);
            VtoV{v1}(1,edges1 == v2) = N_vert + i;
%             edges(:,1) = [v1; NaN; NaN; VtoV{v1}(4,edges1 == v2)+pi; norm(V(v1,:) - Vt)/2];            
            edges(:,1) = [v1; NaN; NaN; VtoV{v1}(4,edges1 == v2)+pi; NaN];                        
            
            % v2 -> v1
            edges2 = VtoV{v2}(1,:);
            VtoV{v2}(1,edges2 == v1) = N_vert + i;
%             edges(:,2) = [v2; NaN; NaN; VtoV{v2}(4,edges2 == v1)+pi; norm(V(v2,:) - Vt)/2];     
            edges(:,2) = [v2; NaN; NaN; VtoV{v2}(4,edges2 == v1)+pi; NaN];                 

            % add new edge
            if i == 1
%                 edges(:,3) = [N_vert + 2; NaN; NaN; theta(i) + pi; norm(M - Vt)];
                edges(:,3) = [N_vert + 2; NaN; NaN; theta(i) + pi; NaN];                
            elseif i == 2
%                 edges(:,3) = [N_vert + 1; NaN; NaN; theta(i) + pi; norm(M - Vt)];
                edges(:,3) = [N_vert + 1; NaN; NaN; theta(i) + pi; NaN];                
            end
            
            VtoV{N_vert + i} = edges;            
        end        

      
        N_vert = N_vert + 2;
        N_vertv = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    else % N_centroids > 2

        V = [Vh; Vv];
        VtoV = VtoVh;
        for vv = 1:N_vertv
            edges = VtoVv{vv};
            E = size(edges,2);
            for e = 1:E
                if edges(1,e) ~= 0
                   edges(1,e) = edges(1,e) + N_verth; 
                end
            end
            VtoV = [VtoV; edges];
        end
%         VtoVv{vv} = edges;
%         
%         VtoV = [VtoVh; VtoVv];
        N_vert = N_verth + N_vertv;
        Vout = [zeros(N_verth,1); find_outside_convex_hull(Vv, Vh, FtoVh)];

        % find intersections
        %intersections might arise due to:
        %-semi-infinite edges
        %-edges towards vertex outside the cu
        %-edges connecting two vertexes outside the cu
        Vt = [];
        N_vert = size(V,1);

        for vv = N_verth+1:N_vert
            
            %-edges connecting two vertexes outside the cu
            if Vout(vv)
%                 VtoV{vv} = NaN;             
%                 V(vv,:) = NaN;
                edges = VtoV{vv};
                E = size(edges, 2);
                for e = 1:E
                    if edges(1,e) ~= 0
                        if Vout(edges(1,e)) == 1
                            V1 = V(vv,:);
                            V2 = V(edges(1,e),:);
                            segmentv = [V1, V2];
                            out = lineSegmentIntersect(segmentv,segmentsh);
                            index = out.intAdjacencyMatrix;
                            indexes = find(index);
                            for i = 1:length(indexes)
                                Vt = [Vt; [out.intMatrixX(indexes(i)), out.intMatrixY(indexes(i)), vv, indexes(i)]];
                            end
                        end                    
                    else %vertex outside the cu, with infinite edges

                        theta = edges(4,e);
                        V1 = V(vv,:);
                        V2 = V(vv,:) + maxrange*[cos(theta), sin(theta)];

                        segmentv = [V1, V2];
                        out = lineSegmentIntersect(segmentv,segmentsh);
                        index = out.intAdjacencyMatrix;
                        indexes = find(index);
                        for i = 1:length(indexes)
                            Vt = [Vt; [out.intMatrixX(indexes(i)), out.intMatrixY(indexes(i)), vv, indexes(i)]];
                        end
                    end
                end

            else
                edges = VtoV{vv};
                E = size(edges, 2);

                for e = 1:E
                    %-semi-infinite edges
                    %-edges towards vertex outside the cu
                    if edges(1,e) == 0 || Vout(edges(1,e))
%                         N_vert = N_vert + 1; %MT check
                        theta = edges(4,e);
                        V1 = V(vv,:);
                        V2 = V(vv,:) + maxrange*[cos(theta), sin(theta)];

                        segmentv = [V1, V2];
                        out = lineSegmentIntersect(segmentv,segmentsh);
                        index = out.intAdjacencyMatrix;
                        Vt = [Vt; [out.intMatrixX(index), out.intMatrixY(index), vv, find(index)]];

                    end        
                end    
            end
        end    
        
        % handle intersections
        facetsi = unique(Vt(:,4));
        N_facetsi = length(facetsi);
        N_vert = size(V,1); %number of vertexes before intersection
        
        for f = 1:N_facetsi
            Vi = Vt(Vt(:,4) == facetsi(f),1:2); %intersections with facet f
            facet = facetsi(f); %intersecting facet
            vv = Vt(Vt(:,4) == facetsi(f),3); %originating vertex
            
            N_intersections = size(Vi,1);
            if N_intersections == 1
                % add new vertex
                V = [V; Vi];
                Vout = [Vout; 0];
                N_vert = N_vert + 1;
                edges = NaN*ones(5, 3);

                % make infinite edge finite
                dist = norm(Vi - V(vv,:));
                edgesvv = VtoV{vv};
                Ev = size(edgesvv,2);
                for ev = 1:Ev % find the infinite edge that gave Vi
                   if edgesvv(1,ev) == 0 || Vout(edgesvv(1,ev))
                       thetavv = edgesvv(4,ev);
                       Vtemp = V(vv,:) + dist*[cos(thetavv), sin(thetavv)];
                       if norm(Vi - Vtemp) < 100*eps
                           edgesvv(1,ev) = N_vert;
                           theta = thetavv;
                           break;
                       end                       
                   end
                end
                VtoV{vv} = edgesvv;
                
                % update edge
                v1 = FtoVh{facet}(1);
                v2 = FtoVh{facet}(2);

                % split existing edge
                % v1 -> v2
                edges1 = VtoV{v1}(1,:);
                VtoV{v1}(1,edges1 == v2) = N_vert;
                edges(:,1) = [v1; NaN; NaN; VtoV{v1}(4,edges1 == v2)+pi; NaN];            

                % v2 -> v1
                edges2 = VtoV{v2}(1,:);
                VtoV{v2}(1,edges2 == v1) = N_vert;
                edges(:,2) = [v2; NaN; NaN; VtoV{v2}(4,edges2 == v1)+pi; NaN];     

%                 distvv = VtoV{vv}(5,VtoV{vv}(1,:) == N_vert);
%                 edges(:,3) = [vv; NaN; NaN; theta + pi; NaN];
                
                VtoV{N_vert} = edges;                            
            else
                v1 = FtoVh{facet}(1);
                v2 = FtoVh{facet}(2);
                V1 = V(v1,:);
                V2 = V(v2,:);

                Vi = find_unique_points(Vi);
                omega = find_offsets(Vi, V1, V2);
                [omega, index] = sort(omega, 'ascend');
                Vi = Vi(index,:);
                N_inter = size(Vi,1);

                % add new vertexes
                V = [V; Vi];
                Vout = [Vout; zeros(N_inter,1)];

                for vu = N_vert + 1:N_vert + N_inter
                   edges = NaN*ones(5, 3);                        
                   if vu == N_vert + 1
                       edgesv1 = VtoV{v1};
                       
                       edges(1,1) = v1;
                       edges(4,1) = edgesv1(4,edgesv1(1,:) == v2) + pi;
%                        edges(5,1) = norm(V(vu,:) - V(v1,:))/2;
                       
                       edges(1,2) = vu+1;
                       edges(4,2) = edgesv1(4,edgesv1(1,:) == v2);
%                        edges(5,2) = norm(V(vu,:) - V(vu+1,:))/2;                       

                       edgesv1(1,edgesv1(1,:) == v2) = vu;
                       VtoV{v1} = edgesv1;

                   elseif vu == N_vert + N_inter

                       edgesv2 = VtoV{v2};
                       
                       edges(1,1) = v2;
                       edges(4,1) = edgesv2(4,edgesv2(1,:) == v1) + pi;
%                        edges(5,1) = norm(V(vu,:) - V(v2,:))/2;
                       
                       edges(1,2) = vu-1;
                       edges(4,2) = edgesv2(4,edgesv2(1,:) == v1);
%                        edges(5,2) = norm(V(vu,:) - V(vu-1,:))/2;                       

                       edgesv2(1,edgesv2(1,:) == v1) = vu;
                       VtoV{v2} = edgesv2;
                   else
                       edgesv1 = VtoV{vu-1};
                       
                       edges(1,1) = vu+1;
                       edges(4,1) = edgesv1(4,edgesv1(1,:) == vu);
%                        edges(5,1) = norm(V(vu,:) - V(vu+1,:))/2;
                       
                       edges(1,2) = vu-1;
                       edges(4,2) = edgesv1(4,edgesv1(1,:) == vu) + pi;
%                        edges(5,2) = norm(V(vu,:) - V(vu-1,:))/2;                       
                       
                   end  
                   edges(1,3) = 0; % MT to be fixed
                   VtoV{vu} = edges;
                end
                N_vert = N_vert + N_inter;
            end
        end


        for vv = N_verth+1:N_verth+N_vertv
            % add missing edges originating from vertexes inside the cu to
            % infinity
            if ~Vout(vv)
                edgesvv = VtoV{vv};
                Evv = size(edgesvv,2);
                for evv = 1:Evv
                    vi = edgesvv(1,evv);
                    if vi > N_verth+N_vertv %vi has been previously identified
                        theta = edgesvv(4,evv);
                        edgesvi = VtoV{vi};
                        edgesvi(1,3) = vv;
                        edgesvi(4,3) = theta + pi;
                        VtoV{vi} = edgesvi;
                    elseif vi == 0 %vi needs to be identified
                        theta = edgesvv(4,evv);
                        dir = [cos(theta), sin(theta)];
                        for vii = N_verth+N_vertv+1:N_vert
                            temp = V(vii,:) - V(vv, :);
                            temp = temp./norm(temp);
                            if dir*temp' > 1 - 100*eps
                                edgesvii = VtoV{vii};
                                edgesvii(1,3) = vv;
                                edgesvii(4,3) = theta+pi;
                                VtoV{vii} = edgesvii;

                                VtoV{vv}(1,edgesvv(1,:) == 0) = vii;
                            end
                        end                        
                    end
                end
                
            elseif Vout(vv)
                edgesvv = VtoV{vv};
                Evv = size(edgesvv,2);
                for evv = 1:Evv
                    v2 = edgesvv(1,evv);
                    if v2 ~= 0
                            
                        %count intersections
                        segmentv = [V(vv,:), V(v2,:)];
                        out = lineSegmentIntersect(segmentv,segmentsh);
                        index = out.intAdjacencyMatrix;

                        if sum(index) == 1

                            theta = edgesvv(4,evv);
                            dir = [cos(theta), sin(theta)];
                            for vi = N_verth+N_vertv+1:N_vert
                                temp = V(vi,:) - V(vv, :);
                                temp = temp./norm(temp);
                                if dir*temp' > 1 - 100*eps
                                    edgesvi = VtoV{vi};
                                    edgesvi(1,3) = v2;
                                    edgesvi(4,3) = theta;
                                    VtoV{vi} = edgesvi;

                                    edgesv2 = VtoV{v2};
                                    VtoV{v2}(1,edgesv2(1,:) == vv) = vi;
                                end
                            end

                        elseif sum(index) == 2                            
                            theta = edgesvv(4,evv);
                            dir = [cos(theta), sin(theta)];
                            vt = [];
                            for vi = N_verth+N_vertv:N_vert
                                temp = V(vi,:) - V(vv, :);
                                temp = temp./norm(temp);
                                if dir*temp' > 1 - 100*eps
                                   vt = [vt, vi]; 
                                end                                
                            end

                            diff = V(vt(2),:) - V(vt(1),:);
                            [theta, rho] = cart2pol(diff(1), diff(2));
%                             dist = norm(diff);

                            edgesvt1 = VtoV{vt(1)};
                            edgesvt1(1,3) = vt(2);
                            edgesvt1(4,3) = theta;
%                             edgesvt1(5,3) = dist/2;
                            VtoV{vt(1)} = edgesvt1;

                            edgesvt2 = VtoV{vt(2)};
                            edgesvt2(1,3) = vt(1);
                            edgesvt2(4,3) = theta + pi;
%                             edgesvt2(5,3) = dist/2;                            
                            VtoV{vt(2)} = edgesvt2;                            
                        end

                    end                        
                end
            end                      
        end

        % remove vertexes outside cu and re-assign labels
        vin = find(Vout == 0);
        N_vert = length(vin);
        V = V(vin,:);
        VtoVnew = cell(N_vert,1);

        for i = 1:N_vert
            VtoVnew{i} = VtoV{vin(i)};            
            
            edges = VtoVnew{i};
            E = size(edges,2);
            for e = 1:E
               VtoVnew{i}(1,e) = find(vin == edges(1,e));
            end            
        end
        VtoV = VtoVnew;
        N_vertv = N_vertv - sum(Vout);
    end
    
    N_vert = size(V, 1);
    Vdist = NaN*ones(N_vert, 1);
    for v = 1:N_vert
        dist = sqrt(sum((repmat(V(v,:), size(centroids,1), 1) - centroids).^2,2));
        [mindist, minindex] = min(dist);
        Vdist(v) = mindist;
        
        if v <= N_verth || v > N_verth + N_vertv%original vertex of the cu or intersection
            edges = VtoV{v};
            E = size(edges,2);
            for e = 1:E
                v2 = edges(1,e);
                V1 = V(v,:);
                V2 = V(v2,:);
                M = (V1+V2)/2;
                dist = sqrt(sum((repmat(M, size(centroids,1), 1) - centroids).^2,2));
                mindist = min(dist);
                nearest_centroids = find(dist == mindist);
                if length(nearest_centroids) == 1
                    edges(2,e) = nearest_centroids; 
                elseif length(nearest_centroids) == 2
                    edges(2:3,e) = nearest_centroids; 
                else
                    warning('more than two nearest centroids');
                end
                c = edges(2,e);
                theta = VtoV{v}(4,e);
                % project centroid on the edge
                distmax = (centroids(c,:) - V(v,:))*[cos(theta);sin(theta)];
                edges(5,e) = distmax;
            end
            VtoV{v} = edges;
        end
    end
end

