function [bestObject, seenObjects] = BatchedAccess(dataService, voronoiDiagram, seenObjects, lambda, densityEstimator, scoreEstimator, M)
    warning('off','MATLAB:catenate:DimensionMismatch');
    
    % batched access
    [Ms, radii] = deterministicPruning(dataService, voronoiDiagram, lambda, densityEstimator, scoreEstimator, M);
    seenObjects = [seenObjects; dataService.accessByScore(floor(Ms));dataService.batchedAccess(voronoiDiagram.vertices.coordinates, radii)];
    
    % compute div score
    seenObjects = computeDivScore(seenObjects, voronoiDiagram.centroids, lambda);
    
    %find best object
    centroidIdxs = ismember(vertcat(seenObjects.features), vertcat(voronoiDiagram.centroids.features), 'rows');
    seenObjects = seenObjects(setdiff(1:length(seenObjects),find(centroidIdxs==1)));
    [~, bestObjectId] = max(vertcat(seenObjects.divScore));
    bestObject = seenObjects(bestObjectId);
end