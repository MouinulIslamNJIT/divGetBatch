function [Ms, r] = deterministicPruning(dataService, voronoiDiagram, lambda, densityEstimator, scoreEstimator, M)
    %% Variables
    V = voronoiDiagram.vertices.coordinates;
    VtoV = voronoiDiagram.topology;
    centroidsFeatures = vertcat(voronoiDiagram.centroids.features);
    factor = voronoiDiagram.vertices.factor;    
    dimensions = dataService.getObjectsDimensions();
    
    epsilon = 1e-15;
    
    numVertexes = size(V, 1);
    distanceBestEdges = NaN*ones(numVertexes, 3);
    bestTau = +Inf;
    
    % can we use score-based accesses?
    scoreBased = true;
    if isempty(scoreEstimator)
        scoreBased = false;
    end
    
    %% Distance functions
    for i=1:numVertexes
        
        edges = VtoV{i};
        vertex = V(i,:);
        
        % find the distance function of the best outgoing edge from the
        % i-th vertex
        [b, c] = computeDistanceCoefficients(edges, vertex, centroidsFeatures);
        idEdgeMin = findBestEdge(edges,  b, c);
        
        if idEdgeMin ~= - 1
            distanceBestEdges(i,:) = [i, b(idEdgeMin), c(idEdgeMin)];
        else
            error('all min points are negative');
            distanceBestEdges(i,:) = [i, 0, 0]; %the vertex has all the minimum point negative, so its radius = 0
        end
    end
    
    %% Compute density function
    rho = densityEstimator.estimate(V);
    
    %% batched access 
    if lambda == 1 || scoreBased == false % particular case batched access distance-based only
        Md = M;
        Ms = 0;
        [bestTau, r] = findBestRadii(distanceBestEdges, Md, rho, factor, epsilon, dimensions);
        r = r';
        
        return;
    
    elseif lambda == 0 % particular case batched access score-based only
       
        Ms = M;
        r = zeros(numVertexes,1);
        return;
    
    end
    
    % batched access score and distance-based
    k = 1;
    Md = 0;
    sampleInterval = 30;
    tau = NaN*ones(1,sampleInterval+1);
    taud = NaN*ones(1,sampleInterval+1);
    taus = NaN*ones(1,sampleInterval+1);
    ws = 1;
    wd = 1;
    
    sDepth = dataService.getSDepth();
    
    while Md <= M
        
        %distance-based component
        [taud(k), r] = findBestRadii(distanceBestEdges, Md, rho, factor, epsilon, dimensions); 
        r = r';
        
        %score-based component
        Ms = (M - wd*Md)/ws;
        taus(k) = scoreEstimator.computeScore(sDepth + Ms);
        
        % check if the new tau is better than the current best one
        tau(k) = (1-lambda)*taus(k) + lambda*taud(k);
        
        if tau(k) < bestTau
            bestTau = tau(k);
            bestR  = r;
            bestMs = Ms;
        end
        
        Md = Md + (M/sampleInterval);
        k = k + 1;
        
    end
    r = bestR;
    Ms = bestMs;
            
            
        