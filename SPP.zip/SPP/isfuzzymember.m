function ids = isfuzzymember(matrix1, matrix2, tolerance)
    ids = zeros(size(matrix1, 1), 1);
    
    if nargin == 2
        tolerance = 1.5*eps;
    end
    
    if size(matrix1, 2) ~= size(matrix2, 2)
        throw(MException('MATLAB:isfuzzymember', 'the two matrices must have the same number of columns'));
    end
    
    for row=1:size(matrix1, 1)
        distances = sqrt(sum((repmat(matrix1(row, :), size(matrix2, 1), 1) - matrix2).^2, 2));
        idxs = find(distances < tolerance);
        if ~isempty(idxs)
            ids(row) = idxs(end);
        end
    end
end

