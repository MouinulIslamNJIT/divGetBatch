function [tau, r] = binarySearch(distanceBestEdges, M, rho, factor, dimensions, distanceUB, distanceLB, epsilon, previousCost, numEquality)

    if (distanceLB > distanceUB) 
        r = -1;
        return;
    end
    
    tau = (distanceLB + distanceUB)/2;
    r = computeSolution(distanceBestEdges, tau);
    cost = computeCost(r, rho, factor, dimensions);
    
    % The budget is too much wrt what we can explore
    if cost == previousCost
       numEquality = numEquality + 1;
    end
    
    if numEquality == 250;
        return
    end
     
    if cost > M
        [tau, r] = binarySearch(distanceBestEdges, M, rho, factor, dimensions, distanceUB, tau, epsilon, cost, numEquality);
    end
    
    if cost < (M - epsilon)
        [tau, r] = binarySearch(distanceBestEdges, M, rho, factor, dimensions, tau, distanceLB, epsilon, cost, numEquality);
    end
        
    