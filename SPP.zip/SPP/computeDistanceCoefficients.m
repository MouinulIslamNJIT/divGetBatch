function [b, c] = computeDistanceCoefficients(edges, vertex, centroids)
    %% Variables
    numEdges = size(edges,2);
    numDimensions = size(vertex,2);
    
    b = NaN*ones(1,numEdges);
    c = NaN*ones(1,numEdges);
    
    %% Compute coefficients for the distance equation
    et = 1;
    for e = 1:numEdges
        if edges(5,e) > 0

            if numDimensions == 2
                theta = edges(4,e);
                dir = [cos(theta), sin(theta)];
            
            elseif numDimensions == 3
            
                dir = [edges(6,e), edges(7,e), edges(8,e)];
            
            end
            
            idCentroid = edges(2,e);
            centroid = centroids(idCentroid,:);
            x1 = sum((centroid - vertex).*dir);
            x2 = sqrt(norm(centroid - vertex)^2 - x1^2);

            b(et) = -2*x1;
            c(et) = x2^2+x1^2;

            et = et + 1;
        end           
    end        
    b = b(1:et - 1);
    c = c(1:et - 1);
    